import { Routes } from '@angular/router';
import { authGuard } from '../app/core/guards/auth-guard';
import { LojaLayoutComponent } from './features/loja/loja-layout/loja-layout.component';
import { HomeComponent } from './features/loja/home/home.component';
import { CardapioComponent } from './features/loja/cardapio/cardapio.component';
import { PedidoComponent } from './features/loja/pedido/pedido.component';
import { AcompanhamentoComponent } from './features/loja/acompanhamento/acompanhamento.component';
import { AdminLayoutComponent } from './features/admin/admin-layout/admin-layout.component';
import { DashboardPageComponent } from './features/admin/pages/dashboard-page/dashboard-page.component';
import { CategoriasPageComponent } from './features/admin/pages/categorias-page/categorias-page.component';
import { ProdutosPageComponent } from './features/admin/pages/produtos-page/produtos-page.component';
import { IngredientesPageComponent } from './features/admin/pages/ingredientes-page/ingredientes-page.component';
import { EstoquePageComponent } from './features/admin/pages/estoque-page/estoque-page.component';
import { PedidosAdminComponent } from './features/admin/pages/pedidos-page/pedidos-admin.component';

export const routes: Routes = [
    {
        path: 'login',
        loadComponent: () =>
            import('./features/login/login.component').then((m) => m.LoginComponent),
    },
    {
        path: 'loja',
        component: LojaLayoutComponent,
        children: [
            { path: 'home', component: HomeComponent },
            { path: 'cardapio', component: CardapioComponent },
            { path: 'pedido', component: PedidoComponent },
            { path: 'acompanhamento', component: AcompanhamentoComponent },
            { path: '', redirectTo: 'home', pathMatch: 'full' },
        ],
    },
    {
        path: 'admin',
        component: AdminLayoutComponent,
        canActivate: [authGuard],
        children: [
            { path: 'dashboard', component: DashboardPageComponent },
            { path: 'categorias', component: CategoriasPageComponent },
            { path: 'produtos', component: ProdutosPageComponent },
            { path: 'ingredientes', component: IngredientesPageComponent },
            { path: 'estoque', component: EstoquePageComponent },
            { path: 'pedidos', component: PedidosAdminComponent },
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
        ],
    },
    {
        path: 'cozinha',
        loadComponent: () => import('./features/cozinha/cozinha.component').then((m) => m.CozinhaComponent), canActivate: [authGuard]
    },
    {
        path: 'notfound',
        loadComponent: () => import('./features/not-found/not-found').then((m) => m.NotFound),
    },
    { path: '**', redirectTo: 'notfound' },

    { path: '', redirectTo: 'loja/home', pathMatch: 'full' },
];

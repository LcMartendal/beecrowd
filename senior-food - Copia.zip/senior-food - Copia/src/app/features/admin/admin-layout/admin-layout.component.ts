import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { VoiceChatbotComponent } from "../../../shared/components/voice-chatbot/voice-chatbot.component";

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [RouterModule, VoiceChatbotComponent],
  templateUrl: './admin-layout.component.html',
})
export class AdminLayoutComponent {}

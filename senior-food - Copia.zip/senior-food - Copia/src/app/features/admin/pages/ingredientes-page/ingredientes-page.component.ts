import { CommonModule } from '@angular/common';
import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
  Calendar,
  Image as ImageIcon,
  LucideAngularModule,
  Pencil,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-angular';
import { TabelaComponent } from '../../../../shared/components/tabela.component';
import { IngredientesService } from '../../../../core/services/ingredientes.service';
import { ToastService } from '../../../../core/services/toast.service';
import { Ingrediente } from '../../../../shared/models/ingrediente.model';
import { BotaoComponent } from '../../../../shared/components/botao.component';
import { CloudinaryService } from '../../../../core/services/cloudinary.service';

@Component({
  selector: 'app-ingredientes-page',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    LucideAngularModule,
    TabelaComponent,
    BotaoComponent,
  ],
  templateUrl: './ingredientes-page.component.html',
  styleUrls: ['./ingredientes-page.component.css'],
})
export class IngredientesPageComponent implements OnInit {
  private ingredientesService = inject(IngredientesService);
  private toastService = inject(ToastService);
  private cloudinaryService = inject(CloudinaryService);

  // Signal para integração com computed
  ingredientes = signal<Ingrediente[]>([]);

  selectedFile: File | null = null;

  ngOnInit(): void {
    this.carregarIngredientes();
  }

  carregarIngredientes() {
    this.ingredientesService.listarTodos().subscribe({
      next: (data) => {
        this.ingredientes.set(data);
      },
      error: () => this.toastService.error('Erro ao carregar ingredientes'),
    });
  }

  readonly icones = { Plus, Pencil, Trash2, Search, X, Calendar, ImageIcon };
  readonly today = new Date();

  busca = signal('');
  showForm = signal(false);
  editando = signal<Ingrediente | null>(null);

  paginaAtual = signal(1);
  totalPaginas = signal(1);

  formData = signal({ nome: '', foto: '', preco: '', quantidadeMinima: 0 });

  filteredIngredientes = computed(() => {
    const ing = this.ingredientes();
    return Array.isArray(ing)
      ? ing.filter((i) =>
          i.nome.toLowerCase().includes(this.busca().toLowerCase()),
        )
      : [];
  });

  openNew() {
    this.formData.set({ nome: '', foto: '', preco: '', quantidadeMinima: 0 });
    this.editando.set(null);
    this.showForm.set(true);
  }

  openEdit(ing: Ingrediente) {
    this.formData.set({
      nome: ing.nome,
      foto: ing.foto || '',
      preco: String(ing.preco || ''),
      quantidadeMinima: ing.quantidadeMinima!,
    });
    this.editando.set(ing);
    this.showForm.set(true);
  }

  salvar() {
    const data = this.formData();
    if (!data.nome.trim()) return;

    if (this.selectedFile) {
      this.cloudinaryService.uploadImage(this.selectedFile).subscribe({
        next: (res) => {
          const imageUrl = res.secure_url;

          this.salvarIngredienteFinal(imageUrl);
        },
        error: () => {
          this.toastService.error('Erro ao enviar imagem');
        },
      });
    } else {
      this.salvarIngredienteFinal(data.foto);
    }
  }

  excluir(id: string) {
    this.ingredientesService.deletar(id).subscribe({
      next: () => {
        this.ingredientes.update((prev) =>
          (Array.isArray(prev) ? prev : []).filter((i) => i.id !== id),
        );
        this.toastService.success('Ingrediente removido com sucesso');
      },
      error: () => this.toastService.error('Erro ao remover ingrediente'),
    });
  }

  salvarIngrediente(ing: Ingrediente) {
    const ingredienteEditando = this.editando();

    if (ingredienteEditando) {
      // Atualização
      this.ingredientesService
        .atualizar(ingredienteEditando.id!, ing)
        .subscribe({
          next: (atualizado) => {
            this.ingredientes.update((lista) =>
              lista.map((i) => (i.id === atualizado.id ? atualizado : i)),
            );
            this.showForm.set(false);
            this.toastService.success('Ingrediente atualizado com sucesso');
          },
          error: () => this.toastService.error('Erro ao atualizar ingrediente'),
        });
    } else {
      // Criação
      this.ingredientesService.cadastrar(ing).subscribe({
        next: (criado) => {
          this.ingredientes.update((lista) => [...lista, criado]);
          this.showForm.set(false);
          this.toastService.success('Ingrediente criado com sucesso');
        },
        error: () => this.toastService.error('Erro ao criar ingrediente'),
      });
    }
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (!file) return;

    this.selectedFile = file;

    const reader = new FileReader();

    reader.onload = () => {
      this.formData.update((data) => ({
        ...data,
        foto: reader.result as string,
      }));
    };

    reader.readAsDataURL(file);
  }

  salvarIngredienteFinal(fotoUrl: string) {
    const data = this.formData();

    const ingrediente: Ingrediente = {
      nome: data.nome,
      foto: fotoUrl,
      preco: data.preco ? parseFloat(data.preco) : 0,
      quantidadeMinima: data.quantidadeMinima,
    };

    const ingredienteEditando = this.editando();

    if (ingredienteEditando) {
      this.ingredientesService
        .atualizar(ingredienteEditando.id!, ingrediente)
        .subscribe({
          next: (atualizado) => {
            this.ingredientes.update((lista) =>
              lista.map((i) => (i.id === atualizado.id ? atualizado : i)),
            );

            this.showForm.set(false);
            this.toastService.success('Ingrediente atualizado com sucesso');
          },
          error: () => this.toastService.error('Erro ao atualizar ingrediente'),
        });
    } else {
      this.ingredientesService.cadastrar(ingrediente).subscribe({
        next: (criado) => {
          this.ingredientes.update((lista) => [...lista, criado]);

          this.showForm.set(false);
          this.toastService.success('Ingrediente criado com sucesso');
        },
        error: () => this.toastService.error('Erro ao criar ingrediente'),
      });
    }
  }
}

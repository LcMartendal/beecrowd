import { CommonModule } from '@angular/common';
import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CategoriaService } from '../../../../core/services/categoria.service';
import { Categoria } from '../../../../shared/models/categoria.model';
import { DialogoComponent } from "../../../../shared/components/dialogo.component";
import { BotaoComponent } from "../../../../shared/components/botao.component";
import { AlertaComponent } from '../../../../shared/components/alerta.component';
import { ToastService } from '../../../../core/services/toast.service';
import { LucideAngularModule, Plus } from "lucide-angular";
import { TabelaComponent } from "../../../../shared/components/tabela.component";


@Component({
  selector: 'app-categorias-page',
  standalone: true,
  imports: [CommonModule, FormsModule, DialogoComponent, BotaoComponent, AlertaComponent, LucideAngularModule, TabelaComponent],
  templateUrl: './categorias-page.component.html',
  styleUrls: ['./categorias-page.component.css']
})
export class CategoriasPageComponent implements OnInit {
  private service = inject(CategoriaService);
  private toast = inject(ToastService);

  categoriaSelecionadaId = signal<string | null>(null);
  categorias = signal<Categoria[]>([]);
  search = signal('');
  modalOpen = signal(false);
  modalTitle = signal('Nova Categoria');
  form = signal<Categoria>({ nome: '', descricao: '' });

  confirmDeleteOpen = signal(false);
  categoriaParaExcluir = signal<Categoria | null>(null);

  readonly icones = { Plus };

  filtered = computed(() => {
    let lista = this.categorias();
    const term = this.search().toLowerCase();
    const catId = this.categoriaSelecionadaId();

    if (catId) {
      lista = lista.filter(c => c.id === catId);
    }

    return lista.filter(c =>
      c.nome.toLowerCase().includes(term) ||
      (c.descricao?.toLowerCase().includes(term) ?? false)
    );
  });
  totalLabel = computed(() => `${this.filtered().length} categorias encontradas`);

  ngOnInit() { this.load(); }

  load() {
    this.service.listarTodos().subscribe(res => this.categorias.set(res.contents));
  }

  openCreate() {
    this.form.set({ nome: '', descricao: '' });
    this.modalTitle.set('Nova Categoria');
    this.modalOpen.set(true);
  }

  edit(c: Categoria) {
    this.form.set({ ...c });
    this.modalTitle.set('Editar Categoria');
    this.modalOpen.set(true);
  }

  handleSave(dados: Categoria) {
    const request = dados.id
      ? this.service.atualizar(dados)
      : this.service.cadastrar(dados);

    request.subscribe(() => {
      this.closeModal();
      this.load();
    });
  }

  remove(c: Categoria) {
    this.categoriaParaExcluir.set(c);
    this.confirmDeleteOpen.set(true);
  }

  confirmarExclusao() {
    const categoria = this.categoriaParaExcluir();
    if (categoria?.id) {
      this.service.deletar(categoria.id).subscribe({
        next: () => {
          this.load();
          this.confirmDeleteOpen.set(false);
        },
        error: (err) => console.error('Erro ao excluir', err)
      });
    }
  }

  closeModal() { this.modalOpen.set(false); }
}

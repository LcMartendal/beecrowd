import { Component, signal } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, LayoutDashboard, Tag, ShoppingBag, Egg, Warehouse, ClipboardList, Zap, ChefHat, ArrowLeft, Menu, X } from 'lucide-angular';

@Component({
  selector: 'app-admin-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, LucideAngularModule],
  templateUrl: './admin-sidebar.component.html'
})
export class AdminSidebarComponent {
  menuAbertoMobile = signal(false);

  readonly icones = { LayoutDashboard, Tag, ShoppingBag, Egg, Warehouse, ClipboardList, Zap, ChefHat, ArrowLeft, Menu, X };

  links = [
    { href: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/admin/categorias', label: 'Categorias', icon: Tag },
    { href: '/admin/produtos', label: 'Produtos', icon: ShoppingBag },
    { href: '/admin/ingredientes', label: 'Ingredientes', icon: Egg },
    { href: '/admin/estoque', label: 'Estoque', icon: Warehouse },
    { href: '/admin/pedidos', label: 'Pedidos', icon: ClipboardList },
  ];

  alternarMobile() {
    this.menuAbertoMobile.update(v => !v);
  }
}

import { CommonModule } from '@angular/common';
import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { RouterLink } from '@angular/router';

import {
  ApiIngrediente,
  ApiPedidosDetalhados,
  PedidoService,
} from '../../core/services/pedido.service';

import { CartaoPedidoComponent } from './components/cartao-pedido/cartao-pedido.component';
import { StatusPedido } from '../../shared/models/status-pedido.model';
import { TipoPedido } from '../../shared/models/tipo-pedido.model';

interface PedidoItemView {
  id: string;
  quantidade: number;
  produtoId?: string;
  nomeProduto: string;
  fotoProduto?: string;
  observacao?: string;
  complementos: ApiIngrediente[];
  ingredientesProduto: ApiIngrediente[];
}

interface PedidoView {
  id: string;
  numero: number;
  tipo: TipoPedido;
  status: StatusPedido;
  total: number;
  horario: string;
  items: PedidoItemView[];
}

@Component({
  selector: 'app-cozinha',
  standalone: true,
  imports: [CommonModule, LucideAngularModule, RouterLink, CartaoPedidoComponent],
  templateUrl: './cozinha.component.html',
  styleUrls: ['./cozinha.component.css']
})
export class CozinhaComponent implements OnInit {
  private pedidoService = inject(PedidoService);

  pedidos = signal<PedidoView[]>([]);
  carregando = signal(false);
  erro = signal('');

  colunas: { status: StatusPedido; label: string; cor: string }[] = [
    {
      status: 'recebido',
      label: 'Recebido',
      cor: 'border-orange-400 bg-orange-50 dark:bg-orange-950/20',
    },
    {
      status: 'preparando',
      label: 'Preparando',
      cor: 'border-yellow-400 bg-yellow-50 dark:bg-yellow-950/20',
    },
    {
      status: 'pronto',
      label: 'Pronto',
      cor: 'border-green-400 bg-green-50 dark:bg-green-950/20',
    },
  ];

  ngOnInit(): void {
    this.carregarPedidos();
  }

  carregarPedidos(): void {
    this.carregando.set(true);
    this.erro.set('');

    this.pedidoService.obterPedidos().subscribe({
      next: (response) => {
        this.pedidos.set(
          (response?.pedidos ?? []).map((pedidoDetalhado) =>
            this.mapPedido(pedidoDetalhado)
          )
        );
        this.carregando.set(false);
      },
      error: (err) => {
        console.error('Erro ao carregar pedidos da cozinha', err);
        this.erro.set('Nao foi possivel carregar os pedidos da cozinha.');
        this.carregando.set(false);
      },
    });
  }

  private normalizarStatus(status: unknown): StatusPedido {
    const value = String(status ?? '').trim().toLowerCase();

    if (
      value === 'recebido' ||
      value === 'preparando' ||
      value === 'pronto' ||
      value === 'entregue'
    ) {
      return value;
    }

    return 'recebido';
  }

  private normalizarTipo(tipo: unknown): TipoPedido {
    const value = String(tipo ?? '').trim().toLowerCase().replace('_', '-');

    if (value === 'balcao' || value === 'drive-thru' || value === 'delivery') {
      return value;
    }

    return 'balcao';
  }

  private mapPedido(source: ApiPedidosDetalhados): PedidoView {
    return {
      id: source.pedido.id,
      numero: source.pedido.numeroPedido,
      tipo: this.normalizarTipo(source.pedido.tipoPedido),
      status: this.normalizarStatus(source.pedido.statusPedido),
      total: Number(source.pedido.precoTotal ?? 0),
      horario: source.pedido.horario,
      items: (source.produtos ?? []).map((produtoDetalhado: any) => {
        const ingredientesPadrao = produtoDetalhado.item.produto?.ingredientes ?? [];

        return {
          id: produtoDetalhado.item.id,
          quantidade: Number(produtoDetalhado.item.quantidade ?? 0),
          produtoId: produtoDetalhado.item.produto?.id,
          nomeProduto: produtoDetalhado.item.produto?.nome ?? 'Produto',
          fotoProduto: produtoDetalhado.item.produto?.foto,
          observacao: produtoDetalhado.item.observacao,
          complementos: produtoDetalhado.item.complementos ?? [],
          ingredientesProduto:
            ingredientesPadrao.length > 0
              ? ingredientesPadrao
              : (produtoDetalhado.ingredientesProduto ?? []),
        };
      }),
    };
  }

  pedidosPorStatus(status: StatusPedido) {
    return computed(() =>
      this.pedidos().filter((pedido) => pedido.status === status)
    );
  }

  private proximoStatusApi(
    statusAtual: StatusPedido
  ): 'PREPARANDO' | 'PRONTO' | 'ENTREGUE' | null {
    if (statusAtual === 'recebido') return 'PREPARANDO';
    if (statusAtual === 'preparando') return 'PRONTO';
    if (statusAtual === 'pronto') return 'ENTREGUE';
    return null;
  }

  avancarPedido(id: string): void {
    const pedido = this.pedidos().find((p) => p.id === id);
    if (!pedido) return;

    const novoStatus = this.proximoStatusApi(pedido.status);
    if (!novoStatus) return;

    this.pedidoService.atualizarStatusPedido(id, novoStatus).subscribe({
      next: () => this.carregarPedidos(),
      error: (err) => {
        console.error('Erro ao avancar status do pedido', err);
      },
    });
  }
}

import { Component, computed, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  LucideAngularModule,
  Clock,
  MapPin,
  Car,
  Truck,
  ArrowRight
} from 'lucide-angular';
import { CronometroComponent } from '../cronometro.component';
import { StatusPedido } from '../../../../shared/models/status-pedido.model';
import { TipoPedido } from '../../../../shared/models/tipo-pedido.model';
import { Ingrediente } from '../../../../shared/models/ingrediente.model';

interface PedidoItemView {
  id: string;
  quantidade: number;
  produtoId?: string;
  nomeProduto: string;
  fotoProduto?: string;
  observacao?: string;
  complementos: Ingrediente[];
  ingredientesProduto: Ingrediente[];
}

interface PedidoView {
  id: string;
  numero: number;
  tipo: TipoPedido;
  status: StatusPedido;
  total: number;
  horario: string;
  items: PedidoItemView[];
}

@Component({
  selector: 'app-cartao-pedido',
  standalone: true,
  imports: [CommonModule, LucideAngularModule, CronometroComponent],
  templateUrl: './cartao-pedido.component.html'
})
export class CartaoPedidoComponent {
  pedido = input.required<PedidoView>();
  aoMover = output<string>();

  readonly icones = { Clock, MapPin, Car, Truck, ArrowRight };

  iconeTipo = computed(() => {
    const tipos: Record<TipoPedido, typeof MapPin> = {
      balcao: MapPin,
      'drive-thru': Car,
      delivery: Truck
    };

    return tipos[this.pedido().tipo] ?? MapPin;
  });

  rotuloBotao = computed(() => {
    const status = this.pedido().status;
    if (status === 'recebido') return 'Preparar';
    if (status === 'preparando') return 'Pronto';
    return 'Entregar';
  });

  listarIngredientes(item: PedidoItemView): string {
    return item.ingredientesProduto.map((i) => i.nome).join(', ');
  }

  listarComplementos(item: PedidoItemView): string {
    return item.complementos.map((c) => c.nome).join(', ');
  }
}

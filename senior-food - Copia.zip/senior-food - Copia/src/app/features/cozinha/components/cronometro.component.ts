import { Component, input, signal, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-cronometro',
  standalone: true,
  template: `<span [class]="classeCor()">{{ tempoFormatado() }}</span>`
})
export class CronometroComponent implements OnInit, OnDestroy {
  horario = input.required<string>();
  tempoSegundos = signal(0);
  private intervalo: any;

  ngOnInit() {
    const inicio = new Date(this.horario()).getTime();
    this.intervalo = setInterval(() => {
      this.tempoSegundos.set(Math.floor((Date.now() - inicio) / 1000));
    }, 1000);
  }

  tempoFormatado() {
    const s = this.tempoSegundos();
    const mins = Math.floor(s / 60);
    const segs = s % 60;
    return `${mins}:${segs.toString().padStart(2, '0')}`;
  }

  classeCor() {
    return this.tempoSegundos() > 300 ? 'text-destructive font-bold' : '';
  }

  ngOnDestroy() {
    if (this.intervalo) clearInterval(this.intervalo);
  }
}

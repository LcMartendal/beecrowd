import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { BotaoComponent } from '../../shared/components/botao.component';

@Component({
  selector: 'app-not-found',
  imports: [ RouterLink, BotaoComponent],
  templateUrl: './not-found.html',
  styleUrls: ['./not-found.css']
})
export class NotFound {

}

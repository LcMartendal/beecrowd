import { CommonModule, formatCurrency } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CartService } from '../../../core/services/cart.service';
import { ToastService } from '../../../core/services/toast.service';
import { TipoPedido } from '../../../shared/models/tipo-pedido.model';

// Ajuste paths conforme sua estrutura

type TipoPedidoOption = {
  tipo: TipoPedido;
  label: string;
  descricao: string;
};

const TIPOS_PEDIDO: TipoPedidoOption[] = [
  { tipo: 'balcao', label: 'Balcao', descricao: 'Retire no balcao da loja' },
  { tipo: 'drive-thru', label: 'Drive-Thru', descricao: 'Retire na pista do drive-thru' },
  { tipo: 'delivery', label: 'Delivery', descricao: 'Receba no seu endereco' },
];

@Component({
  selector: 'app-pedido',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './pedido.component.html',
})
export class PedidoComponent {
  private cart = inject(CartService);
  private toast = inject(ToastService);

  formatCurrency = formatCurrency;

  tiposPedido = TIPOS_PEDIDO;

  tipo: TipoPedido = 'balcao';
  pedidoRealizado: number | null = null;

  // espelha o hook useCart()
  get items() {
    return this.cart.items(); // se for signal: items() ; se for array: ajuste
  }

  removeItem(produtoId: string) {
    this.cart.removeItem(produtoId);
  }

  updateQuantity(produtoId: string, qty: number) {
    this.cart.updateQuantity(produtoId, qty);
  }

  clearCart() {
    this.cart.clearCart();
  }

  setTipo(t: TipoPedido) {
    this.tipo = t;
  }

  get subtotal(): number {
    return this.cart.getTotal();
  }

  get taxaEntrega(): number {
    return this.tipo === 'delivery' ? 8.9 : 0;
  }

  get total(): number {
    return this.subtotal + this.taxaEntrega;
  }

  finalizarPedido() {
    const items = this.items;
    if (!items || items.length === 0) return;

    const numeroPedido = Math.floor(100 + Math.random() * 900);
    this.pedidoRealizado = numeroPedido;

    this.cart.clearCart();
    this.toast.success('Pedido realizado com sucesso!');
  }
}
import type { Categoria } from '../../../shared/models/categoria.model';
import type { Produto } from '../../../shared/models/produto.model';
import type { Ingrediente } from '../../../shared/models/ingrediente.model'; 

// Mock categories
export const categorias: Categoria[] = [
  { id: '1', nome: 'Bebidas', descricao:'descrição' },
  { id: '2', nome: 'Lanches', descricao:'descrição' },
  { id: '3', nome: 'Sobremesas', descricao:'descrição' },
];



// Currency formatter (simple)
export function formatCurrency(value: number): string {
  return value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });
}

// helper to find category by id
export function getCategoriaById(id: string): Categoria | undefined {
  return categorias.find((c) => c.id === id);
}

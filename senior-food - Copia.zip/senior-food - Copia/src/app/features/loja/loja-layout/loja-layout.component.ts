import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

import { HeaderComponent } from '../../../shared/components/header/header.component';
import { FooterComponent } from '../../../shared/components/footer/footer.component';
import { VoiceChatbotComponent } from '../../../shared/components/voice-chatbot/voice-chatbot.component';
import { CartService } from '../../../core/services/cart.service';

@Component({
  selector: 'app-loja-layout',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FooterComponent, VoiceChatbotComponent ],
  templateUrl: './loja-layout.component.html',
  providers: [CartService],
})
export class LojaLayoutComponent { }
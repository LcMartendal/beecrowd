import { Component, input, output, inject } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { LucideAngularModule, Plus } from 'lucide-angular';
import { CarrinhoService } from '../../../../core/services/carrinho.service';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [CommonModule, CurrencyPipe, LucideAngularModule],
  template: `
    <div class="group relative flex flex-col overflow-hidden rounded-xl border bg-card transition-all hover:shadow-lg">
      <div class="aspect-square overflow-hidden bg-muted">
        <img [src]="produto().imagem" class="h-full w-full object-cover transition-transform group-hover:scale-105" />
      </div>
      <div class="p-4">
        <h3 class="font-bold text-foreground">{{ produto().nome }}</h3>
        <div class="mt-4 flex items-center justify-between">
          <span class="text-lg font-black">{{ produto().preco | currency:'BRL' }}</span>
          <button (click)="adicionar($event)" class="rounded-full bg-primary p-2 text-primary-foreground">
            <lucide-icon [name]="icones.Plus" class="h-4 w-4"></lucide-icon>
          </button>
        </div>
      </div>
    </div>
  `
})
export class ProdutoCardComponent {
  private carrinho = inject(CarrinhoService);
  produto = input.required<any>();
  icones = { Plus };

  adicionar(event: MouseEvent) {
    event.stopPropagation();
    this.carrinho.addItem(this.produto());
  }
}

import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import type { Categoria } from '../../../shared/models/categoria.model';
import type { Produto } from '../../../shared/models/produto.model';
import { CartService } from '../../../core/services/cart.service';
import { ToastService } from '../../../core/services/toast.service';
import { categorias, formatCurrency, getCategoriaById } from '../lib/data';
import { ProdutoService } from '../../../core/services/produto.service';
import { ProdutoCardComponent } from './components/produto-card.component';
import { CategoryFilterComponent } from '../../../shared/components/category-filter/category-filter.component';

type Grouped = {
  categoria: Categoria;
  produtos: Produto[];
};

@Component({
  selector: 'app-cardapio',
  standalone: true,
  imports: [CommonModule, ProdutoCardComponent, CategoryFilterComponent],
  templateUrl: './cardapio.component.html',
})
export class CardapioComponent {
  private cart = inject(CartService);
  private toast = inject(ToastService);
  private produtosService = inject(ProdutoService);

  produtos: Produto[] = [];

  selectedCategory: string | null = null;

  detailProduct: Produto | null = null;
  detailQty = 1;

  // expõe pro template
  formatCurrency = formatCurrency;

  setSelectedCategory(categoryId: string | null) {
    this.selectedCategory = categoryId;
  }

  get filtered(): Produto[] {
    return this.selectedCategory
      ? this.produtos.filter((p) => p.categoria.id === this.selectedCategory)
      : this.produtos;
  }

  get grouped(): Grouped[] {
    const filtered = this.filtered;

    if (this.selectedCategory) {
      const cat = getCategoriaById(this.selectedCategory);
      return cat ? [{ categoria: cat, produtos: filtered }] : [];
    }

    return categorias
      .map((cat) => ({
        categoria: cat,
        produtos: filtered.filter((p) => p.categoria.id === cat.id),
      }))
      .filter((g) => g.produtos.length > 0);
  }

  openDetail(produto: Produto) {
    this.detailProduct = produto;
    this.detailQty = 1;
  }

  closeDetail() {
    this.detailProduct = null;
  }

  decQty() {
    this.detailQty = Math.max(1, this.detailQty - 1);
  }

  incQty() {
    this.detailQty = this.detailQty + 1;
  }

  getCategoriaNome(categoriaId: string): string {
    return getCategoriaById(categoriaId)?.nome ?? '';
  }

  addFromDetail() {
    if (!this.detailProduct) return;

    this.cart.addItem(this.detailProduct, this.detailQty);
    this.toast.success(`${this.detailQty}x ${this.detailProduct.nome} adicionado!`);

    this.detailProduct = null;
  }
}
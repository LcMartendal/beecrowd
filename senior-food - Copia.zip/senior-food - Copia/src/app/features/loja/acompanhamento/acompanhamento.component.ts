import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  getOrderStatus,
  STATUS_STEPS,
} from '../../../shared/utils/pedido-status.util';
import { OrderStatusResult } from '../../../shared/models/pedido.model';

@Component({
  selector: 'app-acompanhamento',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './acompanhamento.component.html',
  styleUrls: ['./acompanhamento.component.css'],
})
export class AcompanhamentoComponent {
  numeroPedido = '';
  resultado: OrderStatusResult | null = null;
  buscou = false;

  statusSteps = STATUS_STEPS;

  get currentStepIdx(): number {
    if (!this.resultado) return -1;
    return this.statusSteps.findIndex((s) => s.key === this.resultado!.status);
  }

  onNumeroInput(ev: Event) {
    this.numeroPedido = (ev.target as HTMLInputElement).value;
  }

  buscar() {
    this.buscou = true;
    this.resultado = getOrderStatus(this.numeroPedido);
  }

  // Retorna a classe para o label do step
  stepLabelClass(idx: number): string {
    if (idx === this.currentStepIdx) return 'pedido-step-label-active';
    if (idx < this.currentStepIdx) return 'pedido-step-label-completed';
    return 'pedido-step-label-pending';
  }

  // Retorna a classe para o círculo do ícone do step
  stepIconClass(idx: number): string {
    if (idx === this.currentStepIdx) return 'pedido-step-icon-active';
    if (idx < this.currentStepIdx) return 'pedido-step-icon-completed';
    return 'pedido-step-icon-pending';
  }

  // Retorna a classe da linha que conecta os steps
  lineClass(idx: number): string {
    if (idx < this.currentStepIdx) return 'pedido-step-line-completed';
    return 'pedido-step-line-pending';
  }
}

import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

type CategoryPreview = {
  nome: string;
  descricao: string;
  cor: string;
};

type Step = {
  numero: '01' | '02' | '03';
  titulo: string;
  descricao: string;
};

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './home.component.html',
})
export class HomeComponent {
  categoriesPreview: CategoryPreview[] = [
    { nome: 'Sanduiches', descricao: 'Especiais e classicos', cor: 'bg-primary' },
    { nome: 'Combos', descricao: 'Economia garantida', cor: 'bg-accent' },
    { nome: 'Bebidas', descricao: 'Geladas e refrescantes', cor: 'bg-secondary' },
    { nome: 'Sobremesas', descricao: 'Doces irresistiveis', cor: 'bg-primary' },
  ];

  steps: Step[] = [
    {
      numero: '01',
      titulo: 'Escolha',
      descricao: 'Navegue pelo cardapio e adicione seus favoritos ao carrinho',
    },
    {
      numero: '02',
      titulo: 'Pague',
      descricao: 'Finalize seu pedido de forma rapida e segura',
    },
    {
      numero: '03',
      titulo: 'Retire',
      descricao: 'Retire no balcao, drive-thru ou receba via delivery',
    },
  ];
}
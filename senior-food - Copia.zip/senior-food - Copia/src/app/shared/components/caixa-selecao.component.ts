import { Component, input, model } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, Check } from 'lucide-angular';

@Component({
  selector: 'app-caixa-selecao',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <button
      type="button"
      (click)="selecionado.set(!selecionado())"
      [class.bg-primary]="selecionado()"
      [class.border-primary]="selecionado()"
      class="peer h-4 w-4 shrink-0 rounded-sm border border-input ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 transition-colors"
    >
      @if (selecionado()) {
        <lucide-icon [name]="iconeCheck" class="h-3 w-3 text-primary-foreground mx-auto"></lucide-icon>
      }
    </button>
  `
})
export class CaixaSelecaoComponent {
  selecionado = model<boolean>(false);
  readonly iconeCheck = Check;
}

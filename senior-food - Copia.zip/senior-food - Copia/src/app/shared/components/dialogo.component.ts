import { Component, input, model } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, X } from 'lucide-angular';

@Component({
  selector: 'app-dialogo',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    @if (aberto()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md animate-in fade-in duration-300 p-4">

        <div class="relative w-full max-w-lg border border-border bg-card shadow-2xl rounded-2xl
                    animate-in zoom-in-95 slide-in-from-bottom-4 duration-300 overflow-hidden">


          <div class="p-8">
            <div class="flex flex-col gap-2 text-center sm:text-left mb-6">
              <h2 class="text-2xl font-bold tracking-tight text-foreground">
                <ng-content select="[titulo]"></ng-content>
              </h2>
              <div class="text-sm text-muted-foreground font-medium italic">
                <ng-content select="[descricao]"></ng-content>
              </div>
            </div>

            <div class="py-2 mb-8">
              <ng-content></ng-content>
            </div>

            <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-3 pt-6 border-t border-border/50">
              <ng-content select="[rodape]"></ng-content>
            </div>
          </div>

          <button (click)="aberto.set(false)"
                  class="absolute right-5 top-5 p-2 rounded-full hover:bg-muted text-muted-foreground transition-all duration-200 active:scale-90">
            <lucide-icon [name]="iconeX" class="size-5"></lucide-icon>
            <span class="sr-only">Fechar</span>
          </button>
        </div>
      </div>
    }
  `
})
export class DialogoComponent {
  aberto = model<boolean>(false);
  readonly iconeX = X;
}

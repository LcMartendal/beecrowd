import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contentor-grafico',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="flex aspect-video justify-center text-xs border border-border rounded-xl p-4 bg-card">
      <ng-content></ng-content>
    </div>
  `
})
export class ContentorGraficoComponent {
  configuracao = input.required<any>();
}

import { Component, input, model } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-gaveta',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (aberto()) {
      <div (click)="aberto.set(false)" class="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm animate-in fade-in"></div>
      <div
        class="fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border border-border bg-card shadow-lg animate-in slide-in-from-bottom duration-300"
      >
        <div class="mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted"></div>
        <div class="p-6">
          <h2 class="text-lg font-semibold leading-none tracking-tight mb-2">
            <ng-content select="[titulo]"></ng-content>
          </h2>
          <ng-content></ng-content>
        </div>
      </div>
    }
  `
})
export class GavetaComponent {
  aberto = model<boolean>(false);
}

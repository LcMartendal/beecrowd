import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-separador',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div
      [class.h-px]="orientacao() === 'horizontal'"
      [class.w-full]="orientacao() === 'horizontal'"
      [class.h-full]="orientacao() === 'vertical'"
      [class.w-px]="orientacao() === 'vertical'"
      class="shrink-0 bg-border"
    ></div>
  `
})
export class SeparadorComponent {
  orientacao = input<'horizontal' | 'vertical'>('horizontal');
}

import { Component, model, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-abas',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="flex flex-col gap-2">
      <div class="inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground">
        @for (aba of opcoes(); track aba.valor) {
          <button
            (click)="selecionada.set(aba.valor)"
            [class.bg-background]="selecionada() === aba.valor"
            [class.text-foreground]="selecionada() === aba.valor"
            class="inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50"
          >
            {{ aba.rotulo }}
          </button>
        }
      </div>
      <div class="mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
        <ng-content></ng-content>
      </div>
    </div>
  `
})
export class AbasComponent {
  opcoes = input<{rotulo: string, valor: string}[]>([]);
  selecionada = model<string>('');
}

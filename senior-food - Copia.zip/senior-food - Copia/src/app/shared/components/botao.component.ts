import { Component, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-botao',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button
      [type]="tipo()"
      [class]="classesBotao()"
      [disabled]="desativado()"
    >
      <ng-content></ng-content>
    </button>
  `
})
export class BotaoComponent {
  variante = input<'padrao' | 'destrutivo' | 'contorno' | 'secundario' | 'fantasma' | 'link' | 'sucesso'>('padrao');
  tamanho = input<'padrao' | 'pequeno' | 'grande' | 'icone'>('padrao');
  desativado = input<boolean>(false);

  tipo = input<'button' | 'submit' | 'reset'>('button');
  larguraTotal = input<boolean>(false);

  classesBotao = computed(() => {
    const base = "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium transition-all outline-none focus-visible:ring-2 disabled:pointer-events-none disabled:opacity-50 cursor-pointer";

    const variantes = {
      padrao: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm",
      destrutivo: "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-sm",
      contorno: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
      secundario: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
      fantasma: "hover:bg-accent hover:text-accent-foreground",
      link: "text-primary underline-offset-4 hover:underline",
      sucesso: "bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm"
    };

    const tamanhos = {
      padrao: "h-10 px-4 py-2",
      pequeno: "h-8 rounded-md px-3 text-xs",
      grande: "h-12 rounded-xl px-8 text-base",
      icone: "h-10 w-10"
    };

    const largura = this.larguraTotal() ? 'w-full' : '';

    return `${base} ${variantes[this.variante()]} ${tamanhos[this.tamanho()]} ${largura}`;
  });
}

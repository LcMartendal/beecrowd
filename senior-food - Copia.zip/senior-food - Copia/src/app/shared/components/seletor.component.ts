import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, ChevronDown } from 'lucide-angular';

@Component({
  selector: 'app-seletor',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="relative w-full">
      <button
        (click)="aberto.set(!aberto())"
        class="flex h-9 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
      >
        <span>{{ selecionado() || marcador() }}</span>
        <lucide-icon [name]="iconeDown" class="h-4 w-4 opacity-50"></lucide-icon>
      </button>

      @if (aberto()) {
        <div class="absolute z-50 mt-1 max-h-60 w-full overflow-auto rounded-md border bg-popover text-popover-foreground shadow-md animate-in fade-in zoom-in-95">
          <div class="p-1">
            <ng-content></ng-content>
          </div>
        </div>
      }
    </div>
  `
})
export class SeletorComponent {
  marcador = input<string>('Selecione...');
  selecionado = signal<string | null>(null);
  aberto = signal(false);
  readonly iconeDown = ChevronDown;
}

import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-menu-navegacao',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
    <nav class="flex items-center justify-center gap-1">
      @for (link of links(); track link.rota) {
        <a
          [routerLink]="link.rota"
          routerLinkActive="bg-accent text-accent-foreground"
          class="group inline-flex h-9 w-max items-center justify-center rounded-md px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:outline-none"
        >
          {{ link.rotulo }}
        </a>
      }
    </nav>
  `
})
export class MenuNavegacaoComponent {
  links = input<{rotulo: string, rota: string}[]>([]);
}

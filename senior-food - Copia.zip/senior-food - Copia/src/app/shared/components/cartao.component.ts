import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-cartao',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="rounded-xl border bg-card text-card-foreground shadow-sm flex flex-col gap-4 py-6">
      <div class="px-6 flex flex-col gap-1.5">
        <ng-content select="[titulo]"></ng-content>
        <ng-content select="[descricao]"></ng-content>
      </div>
      <div class="px-6">
        <ng-content></ng-content>
      </div>
      <div class="px-6 mt-auto">
        <ng-content select="[rodape]"></ng-content>
      </div>
    </div>
  `
})
export class CartaoComponent {}

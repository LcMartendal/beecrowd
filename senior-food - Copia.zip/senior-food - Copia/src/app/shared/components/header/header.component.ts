import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { NavigationEnd, Router, RouterModule } from '@angular/router';
import { filter, Subscription } from 'rxjs';

import { CartService } from '../../../core/services/cart.service'; 

type NavLink = { href: string; label: string };

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './header.component.html',
})
export class HeaderComponent implements OnInit, OnDestroy {
  private cart = inject(CartService);
  private router = inject(Router);

  // Ajuste aqui se suas rotas forem diferentes
  brandHref = '/loja';
  pedidoHref = '/loja/pedido';

  navLinks: NavLink[] = [
    { href: '/loja', label: 'Inicio' },
    { href: '/loja/cardapio', label: 'Cardapio' },
    { href: '/loja/pedido', label: 'Meu Pedido' },
    { href: '/loja/acompanhamento', label: 'Acompanhar' },
  ];

  mobileOpen = false;

  // usado pra “active” no menu mobile
  private currentUrl = '';
  private sub?: Subscription;

  get itemCount(): number {
    // ajuste conforme seu CartService:
    // - se getItemCount() existir:
    return this.cart.getItemCount();
    // - se itemCount for signal:
    // return this.cart.itemCount();
  }

  ngOnInit(): void {
    this.currentUrl = this.router.url;
    this.sub = this.router.events
      .pipe(filter((e): e is NavigationEnd => e instanceof NavigationEnd))
      .subscribe((e) => {
        this.currentUrl = e.urlAfterRedirects;
        // geralmente faz sentido fechar menu ao navegar:
        this.mobileOpen = false;
      });
  }

  ngOnDestroy(): void {
    this.sub?.unsubscribe();
  }

  toggleMobile() {
    this.mobileOpen = !this.mobileOpen;
  }

  closeMobile() {
    this.mobileOpen = false;
  }

  isActive(href: string): boolean {
    return this.currentUrl === href;
  }
}
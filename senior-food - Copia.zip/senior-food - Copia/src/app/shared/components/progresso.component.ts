import { Component, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-progresso',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative h-2 w-full overflow-hidden rounded-full bg-primary/20">
      <div
        class="h-full w-full flex-1 bg-primary transition-all duration-300"
        [style.transform]="transformacao()"
      ></div>
    </div>
  `
})
export class ProgressoComponent {
  valor = input<number>(0);

  transformacao = computed(() => `translateX(-${100 - (this.valor() || 0)}%)`);
}

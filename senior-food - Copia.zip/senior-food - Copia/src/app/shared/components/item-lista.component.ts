import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-item-lista',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="group flex items-center justify-between gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/50">
      <div class="flex items-center gap-4">
        <ng-content select="[avatar]"></ng-content>
        <div class="grid gap-1">
          <div class="text-sm font-medium leading-none"><ng-content select="[titulo]"></ng-content></div>
          <div class="text-xs text-muted-foreground"><ng-content select="[subtitulo]"></ng-content></div>
        </div>
      </div>
      <ng-content select="[acoes]"></ng-content>
    </div>
  `
})
export class ItemListaComponent {}

import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-avatar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full border border-border bg-muted">
      @if (urlImagem() && !erroImagem()) {
        <img
          [src]="urlImagem()"
          [alt]="textoAlt()"
          (error)="erroImagem.set(true)"
          class="aspect-square h-full w-full object-cover"
        />
      } @else {
        <div class="flex h-full w-full items-center justify-center rounded-full bg-muted text-xs font-medium uppercase text-muted-foreground">
          {{ iniciais() }}
        </div>
      }
    </div>
  `
})
export class AvatarComponent {
  urlImagem = input<string | undefined>();
  textoAlt = input<string>('Avatar');
  iniciais = input<string>('FX');
  erroImagem = signal(false);
}

import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-grupo-botoes',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div
      class="flex w-fit items-stretch rounded-md shadow-sm"
      [class.flex-row]="orientacao() === 'horizontal'"
      [class.flex-col]="orientacao() === 'vertical'"
    >
      <ng-content></ng-content>
    </div>
  `,
  styles: [`
    :host ::ng-content app-botao button {
      border-radius: 0;
    }
    :host ::ng-content app-botao:first-child button {
      border-top-left-radius: 0.375rem;
      border-bottom-left-radius: 0.375rem;
    }
    :host ::ng-content app-botao:last-child button {
      border-top-right-radius: 0.375rem;
      border-bottom-right-radius: 0.375rem;
      border-left: 0;
    }
  `]
})
export class GrupoBotoesComponent {
  orientacao = input<'horizontal' | 'vertical'>('horizontal');
}

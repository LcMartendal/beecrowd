import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Categoria } from '../../models/categoria.model';

@Component({
  selector: 'app-category-filter',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './category-filter.component.html',
})
export class CategoryFilterComponent {

  categorias = input<Categoria[]>([]);
  selected = input<string | null>(null);

  selectCategory = output<string | null>();

  select(categoryId: string | null) {
    this.selectCategory.emit(categoryId);
  }

  toggle(categoryId: string) {
    const novoValor = this.selected() === categoryId ? null : categoryId;
    this.selectCategory.emit(novoValor);
  }
}

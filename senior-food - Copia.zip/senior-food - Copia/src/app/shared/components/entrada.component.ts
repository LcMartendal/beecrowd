import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-entrada',
  standalone: true,
  imports: [CommonModule],
  template: `
    <input
      [type]="tipo()"
      [placeholder]="marcador()"
      class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
    />
  `
})
export class EntradaComponent {
  tipo = input<string>('text');
  marcador = input<string>('');
}

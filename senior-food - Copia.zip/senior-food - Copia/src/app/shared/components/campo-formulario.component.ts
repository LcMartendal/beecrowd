import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-campo-formulario',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-2">
      <label class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
        <ng-content select="[rotulo]"></ng-content>
      </label>
      <ng-content></ng-content>
      @if (mensagemErro()) {
        <p class="text-xs font-medium text-destructive">{{ mensagemErro() }}</p>
      }
    </div>
  `
})
export class CampoFormularioComponent {
  mensagemErro = input<string | null>(null);
}

import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './footer.component.html',
})
export class FooterComponent {
  brandHref = '/loja';

  links = {
    cardapio: '/loja/cardapio',
    pedido: '/loja/pedido',
    acompanhamento: '/loja/acompanhamento',
    admin: '/admin',
    cozinha: '/cozinha',
  };
}
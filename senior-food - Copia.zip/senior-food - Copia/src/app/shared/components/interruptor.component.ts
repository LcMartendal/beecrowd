import { Component, model } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-interruptor',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button
      type="button"
      (click)="ligado.set(!ligado())"
      [class.bg-primary]="ligado()"
      [class.bg-input]="!ligado()"
      class="peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
    >
      <span
        [class.translate-x-4]="ligado()"
        [class.translate-x-0]="!ligado()"
        class="pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform"
      ></span>
    </button>
  `
})
export class InterruptorComponent {
  ligado = model<boolean>(false);
}

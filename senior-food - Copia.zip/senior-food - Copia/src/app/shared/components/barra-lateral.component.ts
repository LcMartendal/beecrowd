import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-barra-lateral',
  standalone: true,
  imports: [CommonModule],
  template: `
    <aside
      [class.w-64]="expandido()"
      [class.w-16]="!expandido()"
      class="flex h-screen flex-col border-r bg-sidebar text-sidebar-foreground transition-all duration-300"
    >
      <div class="flex h-16 items-center border-b px-4">
        <ng-content select="[cabecalho]"></ng-content>
      </div>
      <div class="flex-1 overflow-y-auto p-2">
        <ng-content></ng-content>
      </div>
      <div class="border-t p-2">
        <ng-content select="[rodape]"></ng-content>
      </div>
    </aside>
  `
})
export class BarraLateralComponent {
  expandido = signal(true);
}

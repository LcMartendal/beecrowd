import { Component, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-etiqueta',
  standalone: true,
  imports: [CommonModule],
  template: `<span [class]="classesEtiqueta()"><ng-content></ng-content></span>`
})
export class EtiquetaComponent {
  variante = input<'padrao' | 'secundario' | 'destrutivo' | 'contorno'>('padrao');

  classesEtiqueta = computed(() => {
    const base = "inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none";

    const variantes = {
      padrao: "border-transparent bg-primary text-primary-foreground",
      secundario: "border-transparent bg-secondary text-secondary-foreground",
      destrutivo: "border-transparent bg-destructive text-white",
      contorno: "text-foreground"
    };

    return `${base} ${variantes[this.variante()]}`;
  });
}

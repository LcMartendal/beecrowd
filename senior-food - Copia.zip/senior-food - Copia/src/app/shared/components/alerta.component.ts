import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-alerta',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div [class]="classesVariante()" role="alert"
         class="relative w-full rounded-xl border p-5 flex gap-4 overflow-hidden transition-all duration-300 shadow-sm">
      <div class="absolute left-0 top-0 bottom-0 w-1.5" [class]="barraLateral()"></div>

      <div class="flex-shrink-0 flex items-center justify-center size-10 rounded-full" [class]="containerIcone()">
        <ng-content select="[icone]"></ng-content>
      </div>

      <div class="flex flex-col gap-1.5">
        <h5 class="font-bold leading-none tracking-tight text-base">
          <ng-content select="[titulo]"></ng-content>
        </h5>
        <div class="text-sm opacity-85 leading-relaxed font-medium">
          <ng-content></ng-content>
        </div>
      </div>
    </div>
  `
})
export class AlertaComponent {
  variante = input<'padrao' | 'destrutivo'>('padrao');

  barraLateral() {
    return this.variante() === 'destrutivo' ? 'bg-red-500' : 'bg-primary';
  }

  containerIcone() {
    return this.variante() === 'destrutivo'
      ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400'
      : 'bg-primary/10 text-primary dark:bg-primary/20';
  }

  classesVariante() {
    return this.variante() === 'destrutivo'
      ? 'border-red-200 text-red-900 bg-red-50/50 dark:border-red-900/50 dark:text-red-200 dark:bg-red-950/20'
      : 'bg-card text-card-foreground border-border shadow-orange-900/5';
  }
}

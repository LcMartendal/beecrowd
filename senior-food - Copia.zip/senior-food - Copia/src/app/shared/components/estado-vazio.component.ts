import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-estado-vazio',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="flex min-h-[400px] flex-col items-center justify-center rounded-md border border-dashed p-8 text-center animate-in fade-in">
      <div class="mx-auto flex max-w-[420px] flex-col items-center justify-center text-center">
        <div class="flex h-20 w-20 items-center justify-center rounded-full bg-muted">
          <ng-content select="[icone]"></ng-content>
        </div>
        <h3 class="mt-4 text-lg font-semibold"><ng-content select="[titulo]"></ng-content></h3>
        <p class="mb-4 mt-2 text-sm text-muted-foreground"><ng-content></ng-content></p>
        <ng-content select="[acao]"></ng-content>
      </div>
    </div>
  `
})
export class EstadoVazioComponent {}

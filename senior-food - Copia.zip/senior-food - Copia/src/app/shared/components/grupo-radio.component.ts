import { Component, input, model } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, Circle } from 'lucide-angular';

@Component({
  selector: 'app-item-radio',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="flex items-center gap-2">
      <button
        type="button"
        (click)="selecionado.set(valor())"
        [class.border-primary]="selecionado() === valor()"
        class="aspect-square size-4 rounded-full border border-input text-primary shadow-sm focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
      >
        @if (selecionado() === valor()) {
          <lucide-icon [name]="iconeCirculo" class="size-2 mx-auto fill-primary"></lucide-icon>
        }
      </button>
      <label class="text-sm font-medium leading-none cursor-pointer" (click)="selecionado.set(valor())">
        <ng-content></ng-content>
      </label>
    </div>
  `
})
export class ItemRadioComponent {
  valor = input.required<string>();
  selecionado = model<string>('');
  readonly iconeCirculo = Circle;
}

import { Component, input, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, ChevronLeft, ChevronRight } from 'lucide-angular';

@Component({
  selector: 'app-calendario',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="p-3 bg-background border rounded-md w-fit">
      <div class="flex justify-between items-center mb-4">
        <button (click)="mesAnterior()" class="h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100">
          <lucide-icon [name]="iconeEsquerda" class="h-4 w-4"></lucide-icon>
        </button>
        <div class="text-sm font-medium">{{ nomeMes() }}</div>
        <button (click)="proximoMes()" class="h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100">
          <lucide-icon [name]="iconeDireita" class="h-4 w-4"></lucide-icon>
        </button>
      </div>
      <div class="grid grid-cols-7 gap-1 text-center text-xs">
        @for (dia of diasSemana; track dia) {
          <div class="text-muted-foreground font-normal w-8">{{ dia }}</div>
        }
      </div>
    </div>
  `
})
export class CalendarioComponent {
  dataSelecionada = output<Date>();
  mesAtual = signal(new Date());

  readonly diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  readonly iconeEsquerda = ChevronLeft;
  readonly iconeDireita = ChevronRight;

  nomeMes() {
    return this.mesAtual().toLocaleString('pt-BR', { month: 'long', year: 'numeric' });
  }

  mesAnterior() { /* lógica para subtrair mês */ }
  proximoMes() { /* lógica para somar mês */ }
}

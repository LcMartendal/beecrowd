import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, ChevronDown } from 'lucide-angular';

@Component({
  selector: 'app-acordeao',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="border-b border-border">
      <button
        (click)="aberto.set(!aberto())"
        class="flex w-full items-center justify-between py-4 text-sm font-medium transition-all hover:underline"
      >
        <ng-content select="[titulo]"></ng-content>
        <lucide-icon
          [name]="iconeChevron"
          class="h-4 w-4 shrink-0 transition-transform duration-200"
          [class.rotate-180]="aberto()"
        ></lucide-icon>
      </button>

      @if (aberto()) {
        <div class="overflow-hidden text-sm pb-4 animate-in fade-in slide-in-from-top-1">
          <ng-content></ng-content>
        </div>
      }
    </div>
  `
})
export class AcordeaoComponent {
  aberto = signal(false);
  readonly iconeChevron = ChevronDown;
}

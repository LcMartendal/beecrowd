import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tabela',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative w-full overflow-auto">
      <table class="w-full caption-bottom text-sm">
        <thead class="[&_tr]:border-b bg-muted/50">
          <ng-content select="[cabecalho]"></ng-content>
        </thead>
        <tbody class="[&_tr:last-child]:border-0">
          <ng-content></ng-content>
        </tbody>
      </table>
    </div>
  `
})
export class TabelaComponent {}

import { Component, inject, effect, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServicoVoz } from '../../../core/services/voz.service';
import { LucideAngularModule, MessageSquare, Mic, MicOff, Send, X } from 'lucide-angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-voice-chatbot',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './voice-chatbot.component.html'
})
export class VoiceChatbotComponent {
  private router = inject(Router);
  servicoVoz = inject(ServicoVoz);
  estaAberto = signal(false);
  readonly icones = { MessageSquare, Mic, MicOff, Send, X };

  constructor() {
    effect(() => {
      if (this.estaAberto() || this.servicoVoz.mensagens().length) {
        setTimeout(() => {
          const elemento = document.querySelector('main');
          if (elemento) elemento.scrollTop = elemento.scrollHeight;
        }, 100);
      }
    });

    effect(() => {
      const texto = this.servicoVoz.transcricao();
      if (texto && !this.servicoVoz.estaOuvindo()) {
        this.enviarMensagem(texto);
        this.servicoVoz.transcricao.set('');
      }
    });
  }

  async enviarMensagem(texto: string) {
    if (!texto.trim() || this.servicoVoz.estaCarregando()) return;

    const currentPath = this.router.url.replace(/^\/|\/$/g, '');
    const elementoMain = document.querySelector('main') || document.body;
    const textoDaTela = elementoMain.innerText.replace(/\s+/g, ' ').trim();

    const contexto = {
      path: currentPath,
      url: window.location.href,
      timestamp: new Date().toISOString(),
      conteudoPagina: textoDaTela
    };

    await this.servicoVoz.enviarParaBackend(texto, contexto);
  }
}

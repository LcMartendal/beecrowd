import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, ChevronLeft, ChevronRight, MoreHorizontal } from 'lucide-angular';

@Component({
  selector: 'app-paginacao',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <nav class="mx-auto flex w-full justify-center" aria-label="paginação">
      <ul class="flex flex-row items-center gap-1">
        <li>
          <button (click)="aoMudarPagina.emit(paginaAtual() - 1)" [disabled]="paginaAtual() === 1"
            class="inline-flex items-center gap-1 px-2.5 py-2 hover:bg-accent rounded-md disabled:opacity-50">
            <lucide-icon [name]="iconeEsquerda" class="size-4"></lucide-icon>
            <span>Anterior</span>
          </button>
        </li>
        <li class="px-4 text-sm font-medium">Página {{ paginaAtual() }} de {{ totalPaginas() }}</li>
        <li>
          <button (click)="aoMudarPagina.emit(paginaAtual() + 1)" [disabled]="paginaAtual() === totalPaginas()"
            class="inline-flex items-center gap-1 px-2.5 py-2 hover:bg-accent rounded-md disabled:opacity-50">
            <span>Próxima</span>
            <lucide-icon [name]="iconeDireita" class="size-4"></lucide-icon>
          </button>
        </li>
      </ul>
    </nav>
  `
})
export class PaginacaoComponent {
  paginaAtual = input<number>(1);
  totalPaginas = input<number>(1);
  aoMudarPagina = output<number>();

  readonly iconeEsquerda = ChevronLeft;
  readonly iconeDireita = ChevronRight;
}

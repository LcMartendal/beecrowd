import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-esqueleto',
  standalone: true,
  imports: [CommonModule],
  template: `<div [class]="'animate-pulse rounded-md bg-muted ' + classePersonalizada()"></div>`
})
export class EsqueletoComponent {
  classePersonalizada = input<string>('');
}

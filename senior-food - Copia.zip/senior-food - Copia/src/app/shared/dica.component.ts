import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dica',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative inline-block" (mouseenter)="exibir.set(true)" (mouseleave)="exibir.set(false)">
      <ng-content></ng-content>
      @if (exibir()) {
        <div class="absolute z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in zoom-in-95 bottom-full mb-2 left-1/2 -translate-x-1/2">
          {{ texto() }}
        </div>
      }
    </div>
  `
})
export class DicaComponent {
  texto = input.required<string>();
  exibir = signal(false);
}

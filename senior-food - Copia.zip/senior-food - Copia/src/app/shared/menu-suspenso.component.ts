import { Component, input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-menu-suspenso',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative inline-block text-left">
      <div (click)="alternar()">
        <ng-content select="[gatilho]"></ng-content>
      </div>

      @if (exibir()) {
        <div
          (click)="exibir.set(false)"
          class="absolute right-0 z-50 mt-2 w-56 origin-top-right rounded-md border border-border bg-popover p-1 text-popover-foreground shadow-md animate-in zoom-in-95"
        >
          <ng-content></ng-content>
        </div>
      }
    </div>
  `
})
export class MenuSuspensoComponent {
  exibir = signal(false);

  alternar() {
    this.exibir.update(v => !v);
  }
}

import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { LucideAngularModule, ChevronRight } from 'lucide-angular';

@Component({
  selector: 'app-navegacao-guia',
  standalone: true,
  imports: [CommonModule, RouterLink, LucideAngularModule],
  template: `
    <nav aria-label="breadcrumb">
      <ol class="flex flex-wrap items-center gap-1.5 text-sm text-muted-foreground">
        @for (item of caminhos(); track item.rotulo; let last = $last) {
          <li class="inline-flex items-center gap-1.5">
            @if (!last) {
              <a [routerLink]="item.link" class="hover:text-foreground transition-colors">
                {{ item.rotulo }}
              </a>
              <lucide-icon [name]="iconeSeta" class="size-4"></lucide-icon>
            } @else {
              <span class="font-normal text-foreground">{{ item.rotulo }}</span>
            }
          </li>
        }
      </ol>
    </nav>
  `
})
export class NavegacaoGuiaComponent {
  caminhos = input.required<{rotulo: string, link?: string}[]>();
  readonly iconeSeta = ChevronRight;
}

export enum TipoPedido {
  DELIVERY = 'DELIVERY',
  BALCAO = 'BALCAO',
  DRIVE_THRU = 'DRIVE_THRU'
}
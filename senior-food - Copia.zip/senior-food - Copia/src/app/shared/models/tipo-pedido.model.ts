export type TipoPedido = 'balcao' | 'drive-thru' | 'delivery';

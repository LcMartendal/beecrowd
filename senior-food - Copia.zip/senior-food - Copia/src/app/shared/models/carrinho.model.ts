import type { Produto } from './produto.model'; // ajuste conforme seu projeto

export interface ItemCarrinho {
  produto: Produto;
  quantidade: number;
  observacoes?: string;
}
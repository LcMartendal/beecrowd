export interface Pagina<T> {
  contents: T[];
  totalElements: number;
  totalPages: number;
}

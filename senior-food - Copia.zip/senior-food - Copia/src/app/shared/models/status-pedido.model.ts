export type StatusPedido = 'recebido' | 'preparando' | 'pronto' | 'entregue';

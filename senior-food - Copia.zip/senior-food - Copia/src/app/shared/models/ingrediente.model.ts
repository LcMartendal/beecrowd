export interface Ingrediente {
  id?: string;
  nome: string;
  preco?: number;
  foto?: string;
  quantidadeMinima?: number;
  quantidadeTotal?: number
}

export interface IngredienteProduto {
  id?: string
  nome: string
}

export interface NotificacaoEstoqueIngrediente {
  nome: string
  observacao: string
  data: Date
}

export interface ResponseNotificacoes {
  notificacoes: NotificacaoEstoqueIngrediente[]
}

export interface EntradaIngredienteEstoque {
  ingredienteId?: string | null;
  quantidade?: number;
}
export type UsuarioVM = {
    nome: string;
    id: string;
}

export type UsuarioUseId = {
    id: string;
}
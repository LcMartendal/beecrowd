export type StatusKey = 'recebido' | 'preparando' | 'pronto' | 'entregue';
export type TipoPedido = 'drive-thru' | 'delivery' | 'balcao';

export interface OrderStatusResult {
  numero: number;
  status: StatusKey;
  tipo: TipoPedido;
  tempoEstimado: string | null;
}

export interface StatusStep {
  key: StatusKey;
  label: string;
  descricao: string;
}


import { Categoria } from "./categoria.model";
import { Ingrediente } from "./ingrediente.model";

export interface Produto {
  id?: string;
  nome: string;
  foto: string;
  categoria:{id: string, nome?: string};
  ingredientes: Ingrediente[];
}

export interface ResponseProduto {
  id?: string;
  nome: string;
  foto: string;
  categoria: Categoria;
  ingredientes: Ingrediente[];
}

export interface ResponseProdutoComIngredientes{
  produtos: Produto[];
}

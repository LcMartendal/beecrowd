import { Ingrediente } from "./ingrediente.model";
import { Item } from "./item.model";
import { StatusPedido } from "./status-pedido.model";
import { TipoPedido } from "./tipo-pedido.model";


export interface Pedido {
  id: string;
  numero: number;
  items: Item[];
  status: StatusPedido;
  tipo: TipoPedido;
  horario: string;
  total: number;
  clienteNome?: string;
}

export interface OrderStatusResult {
  numero: number;
  status: StatusPedido;
  tipo: TipoPedido;
  tempoEstimado: string | null;
}

export interface StatusStep {
  key: StatusPedido;
  label: string;
  descricao: string;
}

export interface SeniorPedidoResponse {
  pedidos: PedidoAgrupado[];
}

export interface PedidoAgrupado {
  pedido: {
    id: string;
    statusPedido: StatusPedido;
    tipoPedido: TipoPedido;
    numeroPedido: number;
    precoTotal: number;
    horario: string;
  };
  produtos: {
    item: {
      id: string;
      quantidade: number;
      produto: {
        id: string;
        nome: string;
        foto?: string;
      };
      observacao?: string;
      complementos: Ingrediente[];
    };
    ingredientesProduto: Ingrediente[];
  }[];
}

export interface InsightsDashboardDTO {
  quantidadePedidosDia: number;
  faturamento: number;
}

export interface CartoesDahsBoardPedido {
  insights: InsightsDashboardDTO;
}

export interface PedidosHoraDTO {
  hora: number;
  quantidade: number;
}

export interface GraficoPedidosHora {
  pedidosHora: PedidosHoraDTO[]
}
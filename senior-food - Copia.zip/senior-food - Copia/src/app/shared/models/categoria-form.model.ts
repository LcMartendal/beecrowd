export interface CategoriaForm {
  id?: string;
  nome: string;
  descricao?: string;
}

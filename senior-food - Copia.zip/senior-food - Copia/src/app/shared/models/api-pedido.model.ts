import { StatusPedido } from './status-pedido.model';
import { TipoPedido } from './tipo-pedido.model';
import { Ingrediente } from './ingrediente.model';
import { Produto } from './produto.model';

/**
 * Interfaces para respostas da API Senior
 */

export interface ApiIngrediente extends Ingrediente {
  id: string;
  _discriminator?: string;
}

export interface ApiProduto extends Produto {
  id: string;
  _discriminator?: string;
}

export interface ApiItem {
  id: string;
  quantidade: number;
  produto?: ApiProduto;
  complementos?: ApiIngrediente[];
  observacao?: string;
  _discriminator?: string;
}

export interface ApiProdutoDetalhado {
  item: ApiItem;
  ingredientesProduto: ApiIngrediente[];
}

export interface ApiPedido {
  id: string;
  statusPedido: StatusPedido;
  tipoPedido: TipoPedido;
  numeroPedido: number;
  precoTotal: number;
  horario: string;
  _discriminator?: string;
}

export interface ApiPedidosDetalhados {
  pedido: ApiPedido;
  produtos: ApiProdutoDetalhado[];
}

export interface ObterPedidosResponse {
  pedidos: ApiPedidosDetalhados[];
}

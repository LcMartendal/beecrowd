import { Ingrediente } from "./ingrediente.model";
import { Pedido } from "./pedido.model";
import { Produto } from "./produto.model";

export interface Item {
  produto: Produto;
  quantidade: number;
}

export interface Item2 {
  id?: string;
  quantidade: number;
  produto?: Produto;
  pedido?: Pedido;
  complementos?: Ingrediente[];
  observacao?: string;
}
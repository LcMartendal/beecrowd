export type UUID = string;

export interface Categoria {
  id?: UUID;
  nome: string;
  descricao?: string;
}


import { OrderStatusResult, StatusStep } from "../models/pedido.model";
import { StatusPedido } from "../models/status-pedido.model";

export const STATUS_STEPS: StatusStep[] = [
  { key: 'recebido', label: 'Pedido Recebido', descricao: 'Seu pedido foi recebido e esta na fila' },
  { key: 'preparando', label: 'Em Preparacao', descricao: 'Nossa equipe esta preparando seu pedido' },
  { key: 'pronto', label: 'Pronto', descricao: 'Seu pedido esta pronto para retirada' },
  { key: 'entregue', label: 'Entregue', descricao: 'Pedido entregue! Bom apetite!' },
];

export function getOrderStatus(numero: string): OrderStatusResult | null {
  const n = parseInt(numero, 10);
  if (Number.isNaN(n)) return null;

  const statuses: StatusPedido[] = ['recebido', 'preparando', 'pronto', 'entregue'];
  const idx = n % 4;

  return {
    numero: n,
    status: statuses[idx],
    tipo: n % 3 === 0 ? 'drive-thru' : n % 3 === 1 ? 'delivery' : 'balcao',
    tempoEstimado: idx < 2 ? `${5 + (3 - idx) * 3} min` : null,
  };
}
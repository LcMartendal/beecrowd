import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-area-texto',
  standalone: true,
  imports: [CommonModule],
  template: `
    <textarea
      [placeholder]="marcador()"
      class="flex min-h-20 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
    ></textarea>
  `
})
export class AreaTextoComponent {
  marcador = input<string>('');
}

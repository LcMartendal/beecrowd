import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private storageKey = 'theme';

  init() {
    const saved = localStorage.getItem(this.storageKey);
    const prefersDark = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const isDark = saved ? saved === 'dark' : prefersDark;
    this.apply(isDark);
  }

  isDark(): boolean {
    return document.documentElement.classList.contains('dark');
  }

  toggle() {
    this.apply(!this.isDark());
  }

  apply(isDark: boolean) {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem(this.storageKey, 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem(this.storageKey, 'light');
    }
  }
}

import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Ingrediente, ResponseNotificacoes } from '../../shared/models/ingrediente.model';

@Injectable({
  providedIn: 'root'
})
export class IngredientesService {

  private http = inject(HttpClient)

  cadastrar(dados: Ingrediente): Observable<any> {
    return this.http.post(`${environment.apiUrl}/entities/ingrediente`, dados);
  }

  atualizar(idIngrediente: string, dados: Ingrediente): Observable<any> {
    return this.http.put(`${environment.apiUrl}/entities/ingrediente/${idIngrediente}`, dados);
  }

  deletar(idIngrediente: string): Observable<any> {
    return this.http.delete(`${environment.apiUrl}/entities/ingrediente/${idIngrediente}`,);
  }

  listarPorId(idIngrediente: string): Observable<Ingrediente> {
    return this.http.get<Ingrediente>(`${environment.apiUrl}/entities/ingrediente/${idIngrediente}`);
  }

  listarTodos(): Observable<Ingrediente[]> {
    return this.http.get<{contents: Ingrediente[]}>(`${environment.apiUrl}/entities/ingrediente`)
      .pipe(map((res) => res.contents))
  }

  notificacoesEstoqueIngrediente(): Observable<ResponseNotificacoes> {
    return this.http.get<ResponseNotificacoes>(`${environment.apiUrl}/queries/obterNotificacoes`);
  }

}

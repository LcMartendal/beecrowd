import { Injectable, signal, computed, effect, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export interface ChatbotMessage {
  autor: 'ia' | 'usuario';
  texto: string;
  timestamp: Date;
}

@Injectable({
  providedIn: 'root',
})
export class ServicoVoz {
  private http = inject(HttpClient);
  private readonly STORAGE_KEY = 'senior_food_chat_history';
  private readonly LIMITE_CONTEXTO_API = 6;

  public transcricao = signal<string>('');
  public estaOuvindo = signal<boolean>(false);
  public estaCarregando = signal<boolean>(false);

  private historicoSignal = signal<ChatbotMessage[]>(this.carregarDoDisco());
  public mensagens = computed(() => this.historicoSignal());

  private reconhecimento: any;
  private sintetizador = window.speechSynthesis;

  constructor() {

    effect(() => {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.historicoSignal()));
    });

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.reconhecimento = new SpeechRecognition();
      this.reconhecimento.lang = 'pt-BR';
      this.reconhecimento.continuous = true;
      this.reconhecimento.interimResults = true;

      this.reconhecimento.onresult = (event: any) => {
        let textoAtual = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          textoAtual += event.results[i][0].transcript;
        }
        this.transcricao.set(textoAtual);
      };

      this.reconhecimento.onend = () => this.estaOuvindo.set(false);
      this.reconhecimento.onerror = () => this.estaOuvindo.set(false);
    }
  }

  async enviarParaBackend(pergunta: string, contextoPagina: any) {
    this.estaCarregando.set(true);
    this.adicionarMensagem('usuario', pergunta);

    const historicoFormatado = this.formatarHistoricoParaTexto();

    try {

      const response = await firstValueFrom(
        this.http.post<any>('https://cloud-leaf.senior.com.br/t/senior.com.br/bridge/1.0/rest/my_domain/my_service/actions/chatIa', {
          pergunta: pergunta,
          path: contextoPagina.path,
          url: contextoPagina.url,
          historico: historicoFormatado,
          conteudoPagina: contextoPagina.conteudoPagina
        })
      );
      this.adicionarMensagem('ia', response.respostaIa);
      this.falar(response.respostaIa);
    } catch (error) {
      this.adicionarMensagem('ia', 'Erro ao conectar com o Senior Food.');
    } finally {
      this.estaCarregando.set(false);
    }
  }

  public adicionarMensagem(autor: 'ia' | 'usuario', texto: string) {
    this.historicoSignal.update(h => [...h, { autor, texto, timestamp: new Date() }]);
  }

  public limparHistorico() {
    this.historicoSignal.set([]);
    localStorage.removeItem(this.STORAGE_KEY);
  }

  private formatarHistoricoParaTexto(): string {
    const mensagensParaContexto = this.mensagens().slice(-this.LIMITE_CONTEXTO_API);

    return mensagensParaContexto
      .map(m => `${m.autor === 'usuario' ? 'Usuário' : 'Assistente'}: ${m.texto}`)
      .join(' | ');
  }

  private carregarDoDisco(): ChatbotMessage[] {
    const salvo = localStorage.getItem(this.STORAGE_KEY);
    return salvo ? JSON.parse(salvo) : [];
  }

  falar(texto: string): void {
    if (this.sintetizador.speaking) this.sintetizador.cancel();
    const mensagem = new SpeechSynthesisUtterance(texto);
    mensagem.lang = 'pt-BR';
    this.sintetizador.speak(mensagem);
  }

  iniciarEscuta(): void {
    this.transcricao.set('');
    this.estaOuvindo.set(true);
    this.reconhecimento.start();
  }

  pararEscuta(): void {
    this.estaOuvindo.set(false);
    this.reconhecimento.stop();
  }
}

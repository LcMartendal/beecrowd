import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { tap, map, catchError } from 'rxjs/operators';
import { UsuarioVM } from '../../shared/models/usuario.models';

interface LoginApiResponse {
    jsonToken: string;
    resetPasswordInfo: {
        expiredPassword: boolean;
        passwordExpiryAt: string;
    };
}

interface ParsedToken {
    access_token: string;
    refresh_token: string;
    token_type: string;
    expires_in: number;
    username: string;
    scope: string;
    version: number;
}

@Injectable({ providedIn: 'root' })
export class AutenticacaoService {
    private apiUrl = environment.apiUrl;

    constructor(private http: HttpClient) { }

    login(username: string, password: string): Observable<UsuarioVM> {
        return this.http
            .post<LoginApiResponse>(`https://cloud-leaf.senior.com.br/t/senior.com.br/bridge/1.0/rest/platform/authentication/actions/login`, { username, password })
            .pipe(
                tap(res => {
                    console.log('[AutenticacaoService] raw login response', res);
                }),
                map(res => JSON.parse((res as any).jsonToken) as ParsedToken),
                tap(parsed => {
                    localStorage.setItem('access_token', parsed.access_token);
                    localStorage.setItem('refresh_token', parsed.refresh_token);
                    localStorage.setItem('expires_in', String(parsed.expires_in));
                    localStorage.setItem('username', parsed.username);
                    localStorage.setItem('id_usuario', parsed.username);
                }),
                map(parsed => ({ id: parsed.username, nome: parsed.username } as UsuarioVM)),
                catchError(err => {
                    console.error('[AutenticacaoService] login error', err);
                    return throwError(() => err);
                })
            );
    }

    logout() {
        localStorage.clear();
    }

    getAccessToken(): string | null {
        return localStorage.getItem('access_token');
    }

    isLoggedIn(): boolean {
        return !!this.getAccessToken();
    }
}

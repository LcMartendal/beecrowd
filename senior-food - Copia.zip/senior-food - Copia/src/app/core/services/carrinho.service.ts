import { Injectable, signal, computed } from '@angular/core';
import { Item } from '../../shared/models/item.model';
import { Produto } from '../../shared/models/produto.model';

@Injectable({
  providedIn: 'root'
})
export class CarrinhoService {
  private cartItems = signal<Item[]>([]);

  items = this.cartItems.asReadonly();

  totalItems = computed(() =>
    this.cartItems().reduce((acc, item) => acc + item.quantidade, 0)
  );

  addItem(produto: Produto) {
    this.cartItems.update(items => {
      const existing = items.find(i => i.produto.id === produto.id);
      if (existing) {
        return items.map(i => i.produto.id === produto.id
          ? { ...i, quantidade: i.quantidade + 1 }
          : i
        );
      }
      return [...items, { produto, quantidade: 1 }];
    });
  }

  removeItem(produtoId: string) {
    this.cartItems.update(items => items.filter(i => i.produto.id !== produtoId));
  }

  clearCart() {
    this.cartItems.set([]);
  }
}

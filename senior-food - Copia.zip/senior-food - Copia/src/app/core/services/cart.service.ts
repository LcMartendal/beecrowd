import { Injectable, computed, signal } from '@angular/core';
import type { Produto } from '../../shared/models/produto.model'; 
import type { ItemCarrinho } from '../../shared/models/carrinho.model';

@Injectable()
export class CartService {
  // Se você preferir global no app inteiro:
  // @Injectable({ providedIn: 'root' })
  // ... e remova providers do layout.

  private readonly _items = signal<ItemCarrinho[]>([]);

  // expõe read-only
  readonly items = this._items.asReadonly();

  addItem(produto: Produto, quantidade = 1, observacoes?: string) {
    if (!produto?.id) return;

    this._items.update((prev) => {
      const existing = prev.find((i) => i.produto.id === produto.id);

      if (existing) {
        return prev.map((i) =>
          i.produto.id === produto.id
            ? { ...i, quantidade: i.quantidade + quantidade }
            : i
        );
      }

      return [...prev, { produto, quantidade, observacoes }];
    });
  }

  removeItem(produtoId: string) {
    this._items.update((prev) => prev.filter((i) => i.produto.id !== produtoId));
  }

  updateQuantity(produtoId: string, quantidade: number) {
    if (quantidade <= 0) {
      this.removeItem(produtoId);
      return;
    }

    this._items.update((prev) =>
      prev.map((i) => (i.produto.id === produtoId ? { ...i, quantidade } : i))
    );
  }

  clearCart() {
    this._items.set([]);
  }

  // “getters” equivalentes ao React (mas reativos)
  readonly total = computed(() =>
    this._items().reduce((sum, i) => sum + ((i.produto.ingredientes?.reduce((sum, ing) => sum + (ing.preco || 0), 0) || 0) * i.quantidade), 0)
  );

  readonly itemCount = computed(() =>
    this._items().reduce((sum, i) => sum + i.quantidade, 0)
  );

  // compat com o código que eu vinha gerando antes
  getTotal(): number {
    return this.total();
  }

  getItemCount(): number {
    return this.itemCount();
  }
}
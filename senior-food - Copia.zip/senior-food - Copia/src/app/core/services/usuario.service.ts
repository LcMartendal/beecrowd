import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UsuarioVM } from '../../shared/models/usuario.models';
import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class UsuarioService {
    private apiEntityUrl = `${environment.apiUrl}/entities/usuario`;
    private apiQueryUrl = `${environment.apiUrl}/queries`;

    constructor(
        private http: HttpClient
    ) {
    }
}

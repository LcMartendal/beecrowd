import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Categoria } from '../../shared/models/categoria.model';
import { environment } from '../../../environments/environment';
import { Pagina } from '../../shared/models/pagina.model';

@Injectable({
  providedIn: 'root'
})
export class CategoriaService {

  private http = inject(HttpClient);


  cadastrar(dados: Categoria): Observable<Categoria> {
    return this.http.post<Categoria>(`${environment.apiUrl}/entities/categoria`, dados);
  }

  atualizar(dados: Categoria): Observable<Categoria> {
    return this.http.put<Categoria>(`${environment.apiUrl}/entities/categoria/${dados.id}`, dados);
  }

  deletar(id: string) {
    return this.http.delete(`${environment.apiUrl}/entities/categoria/${id}`);
  }

  listarTodos(): Observable<Pagina<Categoria>> {
    return this.http.get<Pagina<Categoria>>(`${environment.apiUrl}/entities/categoria`);
  }
}

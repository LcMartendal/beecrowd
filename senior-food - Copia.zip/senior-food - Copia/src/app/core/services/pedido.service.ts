import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ApiIngrediente,
  ApiProduto,
  ApiItem,
  ApiProdutoDetalhado,
  ApiPedido,
  ApiPedidosDetalhados,
  ObterPedidosResponse
} from '../../shared/models/api-pedido.model';
import { CartoesDahsBoardPedido, GraficoPedidosHora } from '../../shared/models/pedido.model';

export type {
  ApiIngrediente,
  ApiProduto,
  ApiItem,
  ApiProdutoDetalhado,
  ApiPedido,
  ApiPedidosDetalhados,
  ObterPedidosResponse
};

@Injectable({ providedIn: 'root' })
export class PedidoService {
  private http = inject(HttpClient);

  obterPedidos(): Observable<ObterPedidosResponse> {
    return this.http.get<ObterPedidosResponse>(
      `${environment.apiUrl}/queries/obterPedidos`
    );
  }

  atualizarStatusPedido(
    idPedido: string,
    statusPedido: 'PREPARANDO' | 'PRONTO' | 'ENTREGUE'
  ): Observable<unknown> {
    return this.http.patch(
      `${environment.apiUrl}/entities/pedido/${idPedido}`,
      { statusPedido }
    );
  }

  cartoesDashboard(): Observable<CartoesDahsBoardPedido> {
    return this.http.get<CartoesDahsBoardPedido>(`${environment.apiUrl}/queries/cartoesDashboard`);
  }

  graficoPedidosHora(): Observable<GraficoPedidosHora> {
    return this.http.get<GraficoPedidosHora>(`${environment.apiUrl}/queries/graficoPedidosHora`);
  }

}

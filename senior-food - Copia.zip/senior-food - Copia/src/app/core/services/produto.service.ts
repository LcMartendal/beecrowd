import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Produto, ResponseProduto } from '../../shared/models/produto.model';

@Injectable({
  providedIn: 'root'
})
export class ProdutoService {

  private http = inject(HttpClient)

  cadastrar(dados: Produto): Observable<any> {
    return this.http.post(`${environment.apiUrl}/entities/produto`, dados);
  }

  atualizar(idProduto: string, dados: Produto): Observable<any> {
    return this.http.post(`${environment.apiUrl}/entities/produto/${idProduto}`, dados);
  }

  listarPorID(idProduto: string): Observable<ResponseProduto> {
    return this.http.get<ResponseProduto>(`${environment.apiUrl}/entities/produto/${idProduto}`);
  }

  listarTodos(): Observable<Produto[]> {
    return this.http.get<Produto[]>(`${environment.apiUrl}/entities/produto`);
  }

  listarTodosComIngrediente(): Observable<Produto[]> {
    return this.http.get<{produtos: Produto[]}>(`${environment.apiUrl}/queries/produtoIngredientes`)
    .pipe(map(res => res.produtos))
  }

  listarTodosComIngredienteECategoria(): Observable<Produto[]> {
    return this.http.get<{ produtos: Produto[] }>(`${environment.apiUrl}my_domain/my_service/queries/produtoIngredientesCategorias`)
      .pipe(map(res => res.produtos))
  }
}

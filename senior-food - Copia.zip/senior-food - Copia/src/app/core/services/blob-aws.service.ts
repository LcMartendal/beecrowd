import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

interface DadosArquivos {
  version: string,
  uri: string
}

@Injectable({
  providedIn: 'root'
})
export class BlobAwsService {

  private http = inject(HttpClient);

  uploadArquivo(fileName: string): Observable<DadosArquivos> {
    return this.http.post<{ version: string; location: { protocol: string; uri: string }; }>
      (`${environment.apiUrl}my_domain/my_service/actions/requestUpload`, {
        acessToken: ' por token',
        fileName: fileName
      }).pipe(
        map((res) => ({
          version: res.version,
          uri: res.location.uri
        }))
      );
  }

  commitArquivo(fileName: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}my_domain/my_service/actions/commitUpload`, {
      acessToken: ' por token',
      fileName: fileName
    });
  }

  downloadArquivo(fileName: string): Observable<any> {
    return this.http.post(`${environment.apiUrl}my_domain/my_service/actions/requestDownload`, {
      acessToken: ' por token',
      fileName: fileName
    });
  }

  upDateAws(img: string, url: string) {
    this.http.put(`${url}`, img);
  }

}

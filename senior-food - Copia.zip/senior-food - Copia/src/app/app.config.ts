import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import {
  LucideAngularModule,
  ChefHat,
  ArrowLeft,
  Clock,
  Zap,
  Mic,
  MicOff,
  MessageSquare,
  Send,
  X
} from 'lucide-angular';

import { routes } from './app.routes';
import { authInterceptor } from './core/interceptors/auth.interceptor';
import { provideHttpClient, withInterceptors } from '@angular/common/http';

export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes), provideHttpClient(withInterceptors([authInterceptor])),


    importProvidersFrom(
      LucideAngularModule.pick({
        ChefHat,
        ArrowLeft,
        Clock,
        Zap,
        Mic,
        MicOff,
        MessageSquare,
        Send,
        X
      })
    )

  ]
};

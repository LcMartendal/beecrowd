import { Injectable, signal } from '@angular/core';

export type ToastKind = 'success' | 'info' | 'warning' | 'error';

export interface ToastItem {
  id: string;
  kind: ToastKind;
  message: string;
  durationMs: number;
  createdAt: number;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  private readonly _toasts = signal<ToastItem[]>([]);
  readonly toasts = this._toasts.asReadonly();

  success(message: string, durationMs = 2500) {
    this.show('success', message, durationMs);
  }

  info(message: string, durationMs = 2500) {
    this.show('info', message, durationMs);
  }

  warning(message: string, durationMs = 3000) {
    this.show('warning', message, durationMs);
  }

  error(message: string, durationMs = 3500) {
    this.show('error', message, durationMs);
  }

  show(kind: ToastKind, message: string, durationMs = 2500) {
    const id = (globalThis.crypto?.randomUUID?.() ?? `t_${Math.random().toString(16).slice(2)}`) as string;

    const toast: ToastItem = {
      id,
      kind,
      message,
      durationMs,
      createdAt: Date.now(),
    };

    this._toasts.update((prev) => [...prev, toast]);

    window.setTimeout(() => this.dismiss(id), durationMs);
  }

  dismiss(id: string) {
    this._toasts.update((prev) => prev.filter((t) => t.id !== id));
  }

  clear() {
    this._toasts.set([]);
  }
}
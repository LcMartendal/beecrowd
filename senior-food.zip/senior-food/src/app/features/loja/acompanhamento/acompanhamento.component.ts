import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { getOrderStatus, STATUS_STEPS } from '../../../shared/utils/pedido-status.util';
import { OrderStatusResult } from '../../../shared/models/pedido.model';


@Component({
  selector: 'app-acompanhamento',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './acompanhamento.component.html',
})
export class AcompanhamentoComponent {
  numeroPedido = '';
  resultado: OrderStatusResult | null = null;
  buscou = false;

  statusSteps = STATUS_STEPS;

  get currentStepIdx(): number {
    if (!this.resultado) return -1;
    return this.statusSteps.findIndex((s) => s.key === this.resultado!.status);
  }

  onNumeroInput(ev: Event) {
    this.numeroPedido = (ev.target as HTMLInputElement).value;
  }

  buscar() {
    this.buscou = true;
    this.resultado = getOrderStatus(this.numeroPedido);
  }
}
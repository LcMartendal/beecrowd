import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  ProdutoModalComponent,
} from '../../../../shared/components/produto-modal/produto-modal.component';
import { TabelaComponent } from "../../../../shared/components/tabela.component";
import { ProdutoService } from '../../../../core/services/produto.service';
import { Produto } from '../../../../shared/models/produto.model';
import { ToastService } from '../../../../core/services/toast.service';
import { IngredientesService } from '../../../../core/services/ingredientes.service';
import { IngredienteProduto } from '../../../../shared/models/ingrediente.model';
import { Categoria } from '../../../../shared/models/categoria.model';
import { CategoriaService } from '../../../../core/services/categoria.service';

@Component({
  selector: 'app-produtos-page',
  standalone: true,
  imports: [CommonModule, FormsModule, ProdutoModalComponent, TabelaComponent],
  templateUrl: './produtos-page.component.html',
  styleUrls: ['./produtos-page.component.css'],
})
export class ProdutosPageComponent implements OnInit {
  private produtoService = inject(ProdutoService);
  private ingredienteService = inject(IngredientesService);
  private categoriaService = inject(CategoriaService);
  private toastService = inject(ToastService);

  produtos: Produto[] = [];
  ingredientes: IngredienteProduto[] = [];
  filtered: Produto[] = [];
  categorias: Categoria[] = [];

  search = '';
  categoriaFiltro: string | 'TODAS' = 'TODAS';

  // modal
  modalOpen = false;
  modalTitle = 'Novo Produto';
  editingProdutoId: string | null = null;
  form: Produto = { nome: '', categoria: { id: '' }, ingredientes: [], foto: '' };

  ngOnInit(): void {
    this.carregarProdutos();
    this.carregarIngredientes();
    this.carregarCategorias();
  }

  carregarProdutos() {
    this.produtoService.listarTodosComIngredienteECategoria().subscribe({
      next: (res) => {
        this.produtos = res
        console.log(res);
        this.aplicarFiltro();
      },
      error: () => this.toastService.error('Erro ao carregar produtos', 3000)
    });
  }

  carregarIngredientes() {
    this.ingredienteService.listarTodos().subscribe({
      next: (res) => {
        this.ingredientes = res
      },
      error: () => this.toastService.error('Erro ao carregar ingredientes', 3000)
    })
  }

  carregarCategorias() {
    this.categoriaService.listarTodos().subscribe({
      next: (res) => {
        this.categorias = res.contents
      },
      error: () => this.toastService.error('Erro ao carregar categorias', 3000)
    })
  }

  get totalLabel() {
    return `${this.filtered.length} produtos cadastrados`;
  }

  aplicarFiltro() {
    const q = this.search.trim().toLowerCase();

    this.filtered = this.produtos.filter((p) => {
      const matchCat = this.categoriaFiltro === 'TODAS' || p.categoria.nome === this.categoriaFiltro;
      return matchCat;
    });
  }

  abrirModalCriar() {
    this.modalTitle = 'Novo Produto';
    this.editingProdutoId = null;
    this.form = { nome: '', categoria: { id: '' }, ingredientes: [], foto: '' };
    this.modalOpen = true;
  }

  fecharModal() {
    this.modalOpen = false;
  }

  acaoSalvarOuAtualizar(payload: Produto) {
    const produtoParaSalvar: Produto = {
      nome: payload.nome,
      categoria: { id: payload.categoria.id! },
      foto: payload.foto || '',
      ingredientes: payload.ingredientes,
    };

    if (this.editingProdutoId) {
      // atualizar
      this.produtoService.atualizar(this.editingProdutoId, produtoParaSalvar).subscribe({
        next: () => {
          this.toastService.success('Produto atualizado com sucesso', 3000);
          this.carregarProdutos();
          this.modalOpen = false;
        },
        error: () => this.toastService.error('Erro ao atualizar produto', 3000),
      });
    } else {
      // criar
      this.produtoService.cadastrar(produtoParaSalvar).subscribe({
        next: () => {
          this.toastService.success('Produto criado com sucesso', 3000);
          this.carregarProdutos();
          this.modalOpen = false;
        },
        error: () => this.toastService.error('Erro ao criar produto', 3000),
      });
    }
  }

  editar(p: Produto) {
    this.modalTitle = 'Editar Produto';
    this.editingProdutoId = p.id!;

    this.form = {
      id: p.id,
      nome: p.nome,
      categoria: { id: p.categoria.id! },
      ingredientes: p.ingredientes || [],
      foto: p.foto || ''
    };

    console.log(this.form)

    this.modalOpen = true;
  }

  remove(p: Produto) {
    //   const ok = confirm(`Excluir "${p.nome}"?`);
    //   if (!ok) return;

    //   if (!p.id) return;
    //   this.produtoService.atualizar(p.id, { ...p, ativo: false }).subscribe({
    //     next: () => {
    //       this.toastService.success('Produto removido com sucesso', 3000);
    //       this.carregarProdutosComIngredientes();
    //     },
    //     error: () => this.toastService.error('Erro ao remover produto', 3000),
    //   });
    // }

    // badgeStatusClass(ativo: boolean) {
    //   return ativo ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600';
  }
}
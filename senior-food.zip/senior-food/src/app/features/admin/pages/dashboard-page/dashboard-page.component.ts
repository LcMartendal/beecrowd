import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PedidoService } from '../../../../core/services/pedido.service';
import { IngredientesService } from '../../../../core/services/ingredientes.service';

type Kpi = {
  label: string;
  value: string;
  icon: 'receipt' | 'dollar' | 'trend' | 'clock';
  iconBg: string;
};

type StockAlert = {
  nome: string;
  minimo?: string;
  atual?: string;
  observacao?: string;
};

type OrderRow = {
  id: string;
  tipo: 'Balcao' | 'Drive-Thru' | 'Delivery';
  status: 'Recebido' | 'Preparando' | 'Pronto' | 'Entregue';
  total: number;
};

@Component({
  selector: 'app-dashboard-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard-page.component.html',
})
export class DashboardPageComponent implements OnInit {

  private pedidoService = inject(PedidoService);
  private ingredienteService = inject(IngredientesService);

  subtitle = 'Visao geral do sistema Fastest X';

  kpis: Kpi[] = [
    { label: 'Pedidos Hoje', value: '0', icon: 'receipt', iconBg: 'bg-[#b7332b]' },
    { label: 'Faturamento', value: 'R$ 0,00', icon: 'dollar', iconBg: 'bg-[#d9b15e]' },
  ];

  hours: string[] = [];
  ordersByHour: number[] = [];

  stockAlerts: StockAlert[] = [];

  lastOrders: OrderRow[] = [];

  ngOnInit(): void {
    this.carregarCartoes();
    this.carregarGrafico();
    this.carregarAlertasEstoque();
  }

  carregarCartoes() {
    this.pedidoService.cartoesDashboard().subscribe(res => {

      const pedidos = res.insights.quantidadePedidosDia;
      const faturamento = res.insights.faturamento;

      this.kpis = [
        {
          label: 'Pedidos Hoje',
          value: pedidos.toString(),
          icon: 'receipt',
          iconBg: 'bg-[#b7332b]'
        },
        {
          label: 'Faturamento',
          value: faturamento.toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL'
          }),
          icon: 'dollar',
          iconBg: 'bg-[#d9b15e]'
        }
      ];
    });
  }

  carregarGrafico() {
    this.pedidoService.graficoPedidosHora().subscribe(res => {

      this.hours = res.pedidosHora.map(p => `${p.hora}h`);
      this.ordersByHour = res.pedidosHora.map(p => p.quantidade);

    });
  }

  carregarAlertasEstoque() {
    this.ingredienteService.notificacoesEstoqueIngrediente().subscribe(res => {

      this.stockAlerts = res.notificacoes.map(n => ({
        nome: n.nome,
        observacao: n.observacao
      }));

    });
  }

  badgeClass(status: OrderRow['status']) {
    switch (status) {
      case 'Recebido':
        return 'bg-orange-100 text-orange-700';
      case 'Preparando':
        return 'bg-yellow-100 text-yellow-800';
      case 'Pronto':
        return 'bg-green-100 text-green-700';
      case 'Entregue':
        return 'bg-blue-100 text-blue-700';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  }

  barHeight(value: number) {
    if (!this.ordersByHour.length) return '0%';

    const max = Math.max(...this.ordersByHour);
    const pct = (value / max) * 100;

    return `${pct}%`;
  }
}
import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../../../core/services/toast.service';

interface EstoqueItem {
  id: string;
  ingredienteId: string;
  quantidade: number;
  quantidadeMinima: number;
  dataVencimento: string;
  lote: string;
}

interface Ingrediente {
  id: string;
  nome: string;
  unidade: string;
}

@Component({
  selector: 'app-estoque-page',
  imports: [CommonModule, FormsModule],
  templateUrl: './estoque-page.component.html',
  styleUrl: './estoque-page.component.css'
})
export class EstoquePageComponent {

  private toastService = inject(ToastService);

  estoqueItems: EstoqueItem[] = [

    // HAMBÚRGUER 180g (3 lotes)

    {
      id: '1',
      ingredienteId: '1',
      quantidade: 30,
      quantidadeMinima: 20,
      dataVencimento: '2026-12-20',
      lote: 'HB-001'
    },
    {
      id: '2',
      ingredienteId: '1',
      quantidade: 15,
      quantidadeMinima: 20,
      dataVencimento: '2026-11-10',
      lote: 'HB-002'
    },
    {
      id: '3',
      ingredienteId: '1',
      quantidade: 5,
      quantidadeMinima: 20,
      dataVencimento: '2026-10-05',
      lote: 'HB-003'
    },

    // QUEIJO CHEDDAR (2 lotes)

    {
      id: '4',
      ingredienteId: '2',
      quantidade: 5,
      quantidadeMinima: 15,
      dataVencimento: '2026-04-10',
      lote: 'CH-001'
    },
    {
      id: '5',
      ingredienteId: '2',
      quantidade: 3,
      quantidadeMinima: 15,
      dataVencimento: '2026-03-15',
      lote: 'CH-002'
    },

    // ALFACE (3 lotes)

    {
      id: '6',
      ingredienteId: '3',
      quantidade: 3,
      quantidadeMinima: 10,
      dataVencimento: '2026-03-06',
      lote: 'AL-001'
    },
    {
      id: '7',
      ingredienteId: '3',
      quantidade: 2,
      quantidadeMinima: 10,
      dataVencimento: '2026-03-08',
      lote: 'AL-002'
    },
    {
      id: '8',
      ingredienteId: '3',
      quantidade: 1,
      quantidadeMinima: 10,
      dataVencimento: '2026-03-05',
      lote: 'AL-003'
    },

    // TOMATE (2 lotes)

    {
      id: '9',
      ingredienteId: '4',
      quantidade: 1,
      quantidadeMinima: 10,
      dataVencimento: '2026-02-20',
      lote: 'TM-001'
    },
    {
      id: '10',
      ingredienteId: '4',
      quantidade: 4,
      quantidadeMinima: 10,
      dataVencimento: '2026-03-12',
      lote: 'TM-002'
    },

    // PÃO BRIOCHE (3 lotes)

    {
      id: '11',
      ingredienteId: '5',
      quantidade: 15,
      quantidadeMinima: 10,
      dataVencimento: '2026-08-15',
      lote: 'PB-001'
    },
    {
      id: '12',
      ingredienteId: '5',
      quantidade: 10,
      quantidadeMinima: 10,
      dataVencimento: '2026-07-20',
      lote: 'PB-002'
    },
    {
      id: '13',
      ingredienteId: '5',
      quantidade: 5,
      quantidadeMinima: 10,
      dataVencimento: '2026-06-30',
      lote: 'PB-003'
    }

  ];

  ingredientes: Ingrediente[] = [
    { id: '1', nome: 'Hambúrguer 180g', unidade: 'un' },
    { id: '2', nome: 'Queijo Cheddar', unidade: 'fatias' },
    { id: '3', nome: 'Alface Americana', unidade: 'un' },
    { id: '4', nome: 'Tomate', unidade: 'kg' },
    { id: '5', nome: 'Pão Brioche', unidade: 'un' }
  ];

  busca = '';
  filtroStatus = 'todos';
  showEntrada = false;

  entradaData = {
    ingredienteId: '',
    quantidade: ''
  };

  constructor() {
    // Define ingrediente padrão do modal
    if (this.estoqueItems.length) {
      this.entradaData.ingredienteId = this.estoqueItems[0].ingredienteId;
    }
  }

  getIngredienteById(id: string): Ingrediente | undefined {
    return this.ingredientes.find(i => i.id === id);
  }

  getStatus(item: EstoqueItem) {
    const today = new Date();
    const vencimento = new Date(item.dataVencimento);
    const diasParaVencer =
      Math.ceil((vencimento.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (diasParaVencer <= 0)
      return { label: 'Vencido', cor: 'status-vermelho', nivel: 3 };

    if (item.quantidade <= item.quantidadeMinima * 0.5)
      return { label: 'Crítico', cor: 'status-vermelho', nivel: 3 };

    if (item.quantidade <= item.quantidadeMinima)
      return { label: 'Baixo', cor: 'status-amarelo', nivel: 2 };

    if (diasParaVencer <= 7)
      return { label: 'Vence em breve', cor: 'status-laranja', nivel: 2 };

    return { label: 'OK', cor: 'status-verde', nivel: 1 };
  }

  get itemsFiltrados() {
    return this.estoqueItems
      .map(e => ({
        ...e,
        ingrediente: this.getIngredienteById(e.ingredienteId),
        status: this.getStatus(e)
      }))
      .filter(e => e.ingrediente)
      .filter(e =>
        !this.busca ||
        e.ingrediente!.nome.toLowerCase().includes(this.busca.toLowerCase())
      )
      .filter(e => {
        if (this.filtroStatus === 'todos') return true;
        if (this.filtroStatus === 'baixo') return e.status.nivel >= 2;
        if (this.filtroStatus === 'critico') return e.status.nivel >= 3;
        return true;
      });
  }

  get totalAlertas() {
    return this.itemsFiltrados.filter(i => i.status.nivel >= 2).length;
  }

  abrirEntrada() {
    this.entradaData = {
      ingredienteId: this.estoqueItems[0]?.ingredienteId || '',
      quantidade: ''
    };
    this.showEntrada = true;
  }

  registrarEntrada() {
    const qtd = parseFloat(this.entradaData.quantidade);

    if (!this.entradaData.ingredienteId || isNaN(qtd) || qtd <= 0) {
      this.toastService.error('Dados inválidos')
      return;
    }

    this.estoqueItems = this.estoqueItems.map(e =>
      e.ingredienteId === this.entradaData.ingredienteId
        ? { ...e, quantidade: e.quantidade + qtd }
        : e
    );

    this.toastService.success('Entrada registrada!');
    this.showEntrada = false;
  }

  ingredienteExpandido: string | null = null;

  toggleIngrediente(id: string) {
    this.ingredienteExpandido =
      this.ingredienteExpandido === id ? null : id;
  }

  get estoqueAgrupado() {

    const grupos: any = {};

    this.itemsFiltrados.forEach(item => {

      if (!grupos[item.ingredienteId]) {
        grupos[item.ingredienteId] = {
          ingrediente: item.ingrediente,
          quantidadeTotal: 0,
          quantidadeMinima: item.quantidadeMinima,
          itens: []
        };
      }

      grupos[item.ingredienteId].quantidadeTotal += item.quantidade;
      grupos[item.ingredienteId].itens.push(item);

    });

    return Object.entries(grupos).map(([id, grupo]: any) => ({
      ingredienteId: id,
      ...grupo
    }));
  }
}
import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LucideAngularModule, Eye, RefreshCw } from 'lucide-angular';

import { ApiIngrediente, ApiPedidosDetalhados, PedidoService } from '../../../../core/services/pedido.service';
import { BotaoComponent } from '../../../../shared/components/botao.component';
import { PedidoModalComponent } from './pedido-modal/pedido-modal.component';

import { StatusPedido } from '../../../../shared/models/status-pedido.model';
import { TipoPedido } from '../../../../shared/models/tipo-pedido.model';

interface PedidoItemView {
  id: string;
  quantidade: number;
  produtoId?: string;
  nomeProduto: string;
  observacao?: string;
  complementos: ApiIngrediente[];
  ingredientesProduto: ApiIngrediente[];
}

interface PedidoView {
  id: string;
  numero: number;
  tipo: TipoPedido;
  status: StatusPedido;
  total: number;
  horario: string;
  items: PedidoItemView[];
}

@Component({
  selector: 'app-pedidos-admin',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    LucideAngularModule,
    BotaoComponent,
    PedidoModalComponent,
  ],
  templateUrl: './pedidos-admin.component.html',
  styleUrls: ['./pedidos-admin.component.css'],
})
export class PedidosAdminComponent implements OnInit {
  private pedidoService = inject(PedidoService);

  readonly Eye = Eye;
  readonly RefreshCw = RefreshCw;

  pedidos: PedidoView[] = [];
  carregando = false;
  erro = '';

  filtroStatus: 'todos' | StatusPedido = 'todos';
  filtroTipo: 'todos' | TipoPedido = 'todos';
  detalhe: PedidoView | null = null;

  ngOnInit(): void {
    this.carregarPedidos();
  }

  carregarPedidos(): void {
    this.carregando = true;
    this.erro = '';

    this.pedidoService.obterPedidos().subscribe({
      next: (response) => {
        this.pedidos = (response?.pedidos ?? []).map((pedidoDetalhado) =>
          this.mapPedido(pedidoDetalhado)
        );
        this.carregando = false;
      },
      error: (err) => {
        console.error('Erro ao carregar pedidos', err);
        this.erro = 'Não foi possível carregar os pedidos.';
        this.carregando = false;
      },
    });
  }

  private mapPedido(source: ApiPedidosDetalhados): PedidoView {
    return {
      id: source.pedido.id,
      numero: source.pedido.numeroPedido,
      tipo: source.pedido.tipoPedido,
      status: source.pedido.statusPedido,
      total: Number(source.pedido.precoTotal ?? 0),
      horario: source.pedido.horario,
      items: (source.produtos ?? []).map((produtoDetalhado: any) => ({
        id: produtoDetalhado.item.id,
        quantidade: Number(produtoDetalhado.item.quantidade ?? 0),
        produtoId: produtoDetalhado.item.produto?.id,
        nomeProduto: produtoDetalhado.item.produto?.nome ?? 'Produto',
        observacao: produtoDetalhado.item.observacao,
        complementos: produtoDetalhado.item.complementos ?? [],
        ingredientesProduto: produtoDetalhado.ingredientesProduto ?? [],
      })),
    };
  }

  get filtered(): PedidoView[] {
    return this.pedidos.filter((pedido) => {
      if (this.filtroStatus !== 'todos' && pedido.status !== this.filtroStatus) {
        return false;
      }

      if (this.filtroTipo !== 'todos' && pedido.tipo !== this.filtroTipo) {
        return false;
      }

      return true;
    });
  }

  abrirDetalhe(pedido: PedidoView): void {
    this.detalhe = pedido;
  }

  fecharDetalhe(): void {
    this.detalhe = null;
  }

  itensCount(pedido: PedidoView): number {
    return pedido.items.reduce(
      (soma, item) => soma + (Number(item.quantidade) || 0),
      0
    );
  }

  formatCurrency(value: number): string {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value ?? 0);
  }

  formatTimeShort(value: string | Date): string {
    const data = value instanceof Date ? value : new Date(value);

    return data.toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  getStatusBadgeClass(status: StatusPedido | string): string {
    const normalized = String(status ?? '').trim().toLowerCase();

    switch (normalized) {
      case 'recebido':
      case 'preparando':
      case 'pronto':
      case 'entregue':
      case 'cancelado':
        return `status-${normalized}`;
      default:
        return 'status-default';
    }
  }
}

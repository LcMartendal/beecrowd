import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, X } from 'lucide-angular';

export interface PedidoItemView {
  id: string;
  quantidade: number;
  produtoId?: string;
  nomeProduto: string;
  observacao?: string;
  complementos: { id: string; nome: string; preco?: number; }[];
  ingredientesProduto: { id: string; nome: string; preco?: number; }[];
}

export interface PedidoView {
  id: string;
  numero: number;
  tipo: 'balcao' | 'drive-thru' | 'delivery';
  status: 'recebido' | 'preparando' | 'pronto' | 'entregue' | 'cancelado';
  total: number;
  horario: string | Date;
  items: PedidoItemView[];
}

@Component({
  selector: 'app-pedido-modal',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './pedido-modal.component.html',
  styleUrl: './pedido-modal.component.css'
})
export class PedidoModalComponent {
  readonly X = X;

  pedido = input<PedidoView | null>(null);
  close = output<void>();

  fecharModal(): void {
    this.close.emit();
  }

  stopPropagation(ev: Event): void {
    ev.stopPropagation();
  }

  formatCurrency(value: number): string {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value ?? 0);
  }

  formatTimeShort(value: string | Date): string {
    const d = value instanceof Date ? value : new Date(value);
    return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }
}

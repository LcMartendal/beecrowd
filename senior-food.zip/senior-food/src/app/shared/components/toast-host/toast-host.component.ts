import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ToastItem, ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-toast-host',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './toast-host.component.html',
})
export class ToastHostComponent {
  toast = inject(ToastService);

  kindClasses(kind: ToastItem['kind']): string {
    switch (kind) {
      case 'success':
        return 'border-green-200 bg-green-50 text-green-900';
      case 'info':
        return 'border-blue-200 bg-blue-50 text-blue-900';
      case 'warning':
        return 'border-yellow-200 bg-yellow-50 text-yellow-900';
      case 'error':
        return 'border-red-200 bg-red-50 text-red-900';
    }
  }

  iconKind(kind: ToastItem['kind']): 'success' | 'info' | 'warning' | 'error' {
    return kind;
  }
}
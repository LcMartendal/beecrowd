import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Produto } from '../../models/produto.model';
import { Categoria } from '../../models/categoria.model';
import { Ingrediente } from '../../models/ingrediente.model';

@Component({
  selector: 'app-produto-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './produto-modal.component.html',
})
export class ProdutoModalComponent implements OnChanges {
  @Input({ required: true }) open = false;
  @Input() title = 'Novo Produto';

  @Input() categorias: Categoria[] = [];
  @Input() ingredientes: Ingrediente[] = [];

  @Input() model!: Produto;

  localModel!: Produto;

  @Output() close = new EventEmitter<void>();
  @Output() save = new EventEmitter<Produto>();


  ngOnChanges(changes: SimpleChanges) {
    if (changes['model'] && this.model) {
      this.localModel = JSON.parse(JSON.stringify(this.model));
    }
  }

  aoFechar() {
    this.close.emit();
  }

  parar(e: MouseEvent) {
    e.stopPropagation();
  }

  aoSalvar() {
    if (!this.model.nome.trim()) return;
    if (!this.model.categoria.id) return;

    this.save.emit({
      ...this.model,
      nome: this.model.nome.trim(),
      ingredientes: this.model.ingredientes ?? [],
    });
  }

  aoMudarArquivo(evt: Event) {
    const input = evt.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      this.model.foto = String(reader.result);
    };
    reader.readAsDataURL(file);
  }

  removerFoto() {
    this.model.foto = '';
  }

  toggleIngrediente(ingrediente: Ingrediente) {
    if (!this.model.ingredientes) {
      this.model.ingredientes = [];
    }

    const existe = this.model.ingredientes.find(i => i.id === ingrediente.id);

    if (existe) {
      this.model.ingredientes = this.model.ingredientes.filter(i => i.id !== ingrediente.id);
    } else {
      this.model.ingredientes.push(ingrediente);
    }
  }

  estaSelecionado(id: string) {
    return this.model.ingredientes?.some(i => i.id === id);
  }
}
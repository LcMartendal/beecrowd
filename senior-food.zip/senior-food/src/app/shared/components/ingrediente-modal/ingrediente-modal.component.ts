import { Component } from '@angular/core';

@Component({
  selector: 'app-ingrediente-modal',
  imports: [],
  templateUrl: './ingrediente-modal.component.html',
  styleUrl: './ingrediente-modal.component.css'
})
export class IngredienteModalComponent {

}

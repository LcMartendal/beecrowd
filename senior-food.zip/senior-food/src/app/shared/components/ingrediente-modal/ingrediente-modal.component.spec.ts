import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IngredienteModalComponent } from './ingrediente-modal.component';

describe('IngredienteModalComponent', () => {
  let component: IngredienteModalComponent;
  let fixture: ComponentFixture<IngredienteModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [IngredienteModalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IngredienteModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, EventEmitter, Input, Output, model } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DialogoComponent } from '../dialogo.component';
import { CampoFormularioComponent } from '../campo-formulario.component';
import { BotaoComponent } from '../botao.component';
import { CategoriaForm } from '../../models/categoria-form.model';



@Component({
  selector: 'app-categoria-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, DialogoComponent, CampoFormularioComponent, BotaoComponent],
  templateUrl: './categoria-modal.component.html',
})
export class CategoriaModalComponent {
  open = model<boolean>(false);

  @Input() title = 'Nova Categoria';
  @Input() modelData: CategoriaForm = { nome: '', descricao: '' };

  @Output() save = new EventEmitter<CategoriaForm>();

  onClose() {
    this.open.set(false);
  }

  onSave() {
    if (!this.modelData.nome?.trim()) return;

    this.save.emit({
      ...this.modelData,
      nome: this.modelData.nome.trim(),
      descricao: (this.modelData.descricao ?? '').trim(),
    });
  }
}
